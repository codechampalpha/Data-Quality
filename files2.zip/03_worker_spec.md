# 03 — Worker Specification (File Watcher · Dispatcher · Rule Engine)

> **Module role:** the only component that reads input files, executes rule code, and writes `dq_output`. Plain Python process (no web framework). Reads contract 01 only. Communicates with the rest of the system exclusively through PostgreSQL tables — it never calls the API and is never called by it.
> **Agent rules:** repo layout `worker/main.py` (entry: starts poller thread + dispatcher loop), `worker/poller.py`, `worker/dispatcher.py`, `worker/engine.py`, `worker/rule_runtime.py`, `worker/output_writer.py`, `worker/retention.py`, `worker/summaries.py`, `worker/compare.py`, `worker/db.py`, `worker/storage/` (abstraction layer, §11), `worker/settings.py` (env-driven). pandas 2.2 + numpy + psycopg2 only. Unit tests per module with small fixture CSVs.

## 1. Process model

One Worker pod runs:
- **Poller thread** — scans NDM paths every `POLL_INTERVAL_SEC` (default 90).
- **Dispatcher loop** — claims Queued runs, executes in `ProcessPoolExecutor(max_workers=MAX_PARALLEL_RUNS)` (default 2). Each run executes in a child process (isolates memory; a crashed run cannot take down the worker).
- Graceful shutdown on SIGTERM: stop claiming, let in-flight runs finish (OpenShift `terminationGracePeriodSeconds` ≥ 900).
- Crash recovery on startup: any run stuck in Running with no live process → mark Failed ("worker restarted mid-run"), truncate its partition if present.

Scaling later: multiple worker pods work unchanged on PostgreSQL because claiming uses `FOR UPDATE SKIP LOCKED`; on SQLite the dialect default is MAX_PARALLEL_RUNS=1 (§11.5).

## 2. Poller (file watcher)

For each active `dataset` with `source_type='ndm'`:
1. Resolve today's (or the month's) expected `file_pattern` / `count_file_pattern` (support `{YYYYMMDD}`, `{YYYYMM}` tokens).
2. Both files present and data-file size stable across two polls (still-transferring guard) →
3. Upsert `dataset_batch` (dataset_id, batch_date) — re-arrival same day updates the same row and re-triggers (overwrite semantics).
4. Parse count file → `expected_count`. Batch → `Ready`.
5. For every Active workflow on this dataset with `trigger_mode='auto'`: INSERT `workflow_run` (Queued, trigger_type='auto', triggered_by='system'). If the unique active-run index rejects (already queued/running) → skip silently.
Manual runs arrive the same way (API inserts the row) — one code path from here on.

## 3. Rule contract (runtime side)

Every `rule_version.python_expression` is the **body** of:

```python
def evaluate(df: pd.DataFrame, column: str, lookups: dict[str, pd.Series], params: dict) -> pd.Series:
    # returns boolean Series aligned to df.index; True = Pass
```

- `df` — full batch, ALL columns dtype=str (loaded with `dtype=str, keep_default_na=False`); empty string means empty, never NaN. Rules treat df as read-only.
- `column` — the mapped target column (one rule serves many columns).
- `lookups` — `{lookup_alias: pd.Series}`; each Series is the `lookup_column` of the bound ref_dataset, loaded once per run and shared across mappings of the same rule version.
- `params` — `parameter_schema` defaults overlaid with `workflow_rule_mapping.parameters`.
- Return value is normalized: `result.fillna(False).astype(bool)` → NaN = Fail.
- Future fail_reason: engine wraps every result in an internal `RuleResult(passed: Series, reason: Series|None)`; v1 persists only `passed`. Contract v2 may return a tuple — engine detects tuple vs Series. DO NOT expose reason columns in v1.

### 3.1 Compilation & restricted namespace

```python
SAFE_BUILTINS = {n: getattr(builtins, n) for n in (
    "len","range","str","int","float","bool","min","max","sum","abs","round",
    "sorted","enumerate","zip","list","dict","set","tuple","any","all","isinstance")}
ALLOWED_GLOBALS = {"pd": pd, "np": np, "re": re, "datetime": datetime, "__builtins__": SAFE_BUILTINS}

def build_rule_fn(expression: str, rule_code: str):
    src = "def evaluate(df, column, lookups, params):\n" + textwrap.indent(expression, "    ")
    ns = {}
    exec(compile(src, f"<rule:{rule_code}>", "exec"), dict(ALLOWED_GLOBALS), ns)
    return ns["evaluate"]
```

Guardrail (not a sandbox — Creators are trusted, code is UAT-tested): no `open`, `__import__`, `exec`, `eval`, no os/sys. Compile errors at step COMPILE fail the run with the rule name and SyntaxError text in `error_message`.

## 4. Run lifecycle (engine.py) — phases, progress, failure policy

Claim (dispatcher): `QueueClaimer.claim_next()` — dialect-safe claim per §11.1 (BEGIN IMMEDIATE guard on SQLite; FOR UPDATE SKIP LOCKED on PostgreSQL).

| # | Phase | progress_pct | Work | Failure handling |
|---|---|---|---|---|
| 1 | VALIDATE | 0–5 | Batch is Ready; file exists/readable; every active mapping resolves to an Approved rule_version; every rule's `required_columns` ⊆ dataset columns; every lookup binding resolves to an active ref_dataset containing `lookup_column`; parameters validate against parameter_schema | Fail fast, precise error_message, batch untouched |
| 2 | SNAPSHOT | 5 | Write `rule_versions_used` = {rule_id: rule_version_id}; begin engine_log with resolved config + full generated source of every rule (audit: exactly what ran; NO data values ever) | — |
| 3 | LOAD | 5–10 | `pd.read_csv(dtype=str, keep_default_na=False, sep=delimiter)`; row count vs expected_count → mismatch: batch `CountMismatch`, run Failed; assign `rec_id = batch_id*10**9 + np.arange(1, n+1)`; load each distinct lookup Series | Fail → nothing written |
| 4 | COMPILE | 10 | build_rule_fn per distinct rule_version | Fail run |
| 5 | EXECUTE | 10–80 | Mappings in display_order: `passed = fn(df, m.column, m.lookups, m.params)`; `out[m.result_column] = np.where(passed.fillna(False), 'P','F')`; after each mapping update progress_pct + current_step = `Executing rule {i}/{n}: {rule_name} on {column}`; check cancel flag between rules (Cancelled → cleanup, stop) | ANY exception → run Failed, full traceback in engine_log, message `Rule '{rule_name}' on '{column}': {exc}` in error_message, NOTHING written (00 §6.4) |
| 6 | WRITE | 80–92 | PartitionManager.ensure_table + prepare_batch (overwrite semantics), then BulkWriter.write of the assembled wide frame — dialect-appropriate bulk path per §11 | write error → PartitionManager.cleanup_failed, run Failed |
| 7 | SUMMARIZE | 92–97 | Insert run_rule_summary (value_counts per result column). Groups: per group, `pass_rate = Σpassed/Σtotal`, `weighted = Σ(w·passed)/Σ(w·total)` over member mappings; status from thresholds: rate≥pass_threshold→Pass, rate<fail_threshold→Fail, else Warning (rate = weighted if use_weighted) | Fail → keep output, mark run Failed with summary error (rare; summaries recomputable) |
| 8 | RETIRE | 97–99 | PartitionManager.retire(workflow, retention_batches) — DELETE-by-date on SQLite, DROP-partition on PG (§11.3) | Log, don't fail run |
| 9 | COMPLETE | 100 | status Completed, completed_at, batch `Processed`, flush engine_log | — |

Write strategy is single-write by design (00 §6.1): no raw pre-load, no half-processed visibility, trivial cleanup.

## 5. Output writer details

- Column order: `rec_id, batch_date, run_id`, dataset columns by ordinal_position, result columns by display_order (00 §6.7).
- Quote result column identifiers (mixed case codes like `R101_city`).
- Physical batch management is delegated entirely to PartitionManager (§11.3): SQLite keeps one plain table; PostgreSQL uses daily `FOR VALUES FROM ('2026-07-14') TO ('2026-07-15')` / monthly first-to-first partitions.
- New mapping on an Active workflow: the API already ALTERed the table; writer introspects information_schema before COPY and errors clearly if a result column is missing (defense in depth).

## 6. Dry-run jobs (rule testing service for the API)

A tiny second queue table is NOT needed: dry-runs are `workflow_run`-independent. Implement as table `dry_run_job(job_id, rule_version_id, column_name, parameters JSONB, sample_path, status, result JSONB, created_by, created_at)` claimed by the same dispatcher with priority over full runs. Execution: load sample CSV (≤ 100K rows), compile the single rule, evaluate, return `{passed, failed, sample_failing_rec_rows (max 20, ONLY the tested column + required_columns values)}`. Add this table to 01 in a contract-change note if implemented (flag to the user first — see 00 header rule).

## 7. Comparison utility (Experian parallel validation)

`worker/compare.py`, CLI-invoked (Creator/Admin usage during cutover):
```
python -m worker.compare --workflow-id 12 --batch-date 2026-07-14 --experian-file /path/export.csv --mapping mapping.yaml
```
- `mapping.yaml`: maps Experian result column names → our `result_column` names, and Experian verdict tokens → P/F.
- Join key: file row position. Experian export preserves input order → row_number = position; ours = `rec_id % 10^9`.
- Output: per result column — matches, mismatches, mismatch rate; CSV of mismatching row numbers with both verdicts (no PII columns). Cutover criterion: an agreed window (e.g., 2–4 weeks) of daily batches with zero unexplained mismatches.

## 8. Logging & observability

- Structured logs (JSON lines) to stdout for OpenShift collection: run_id, workflow_id, phase, duration_ms, rows. Never data values.
- `engine_log` per run: generated rule sources + phase timings + per-rule row counts. Size-cap 1 MB (truncate middle).
- Timing expectation @500K rows: LOAD 10–30s, EXECUTE ~0.2–1s per vectorized rule, WRITE 20–60s. A run exceeding `RUN_TIMEOUT_MIN` (default 60) → killed, Failed, partition truncated.

## 9. Configuration (env)

`DATABASE_URL, NDM_ROOT, POLL_INTERVAL_SEC=90, MAX_PARALLEL_RUNS=2, RUN_TIMEOUT_MIN=60, COPY_CHUNK_ROWS=50000, LOG_LEVEL`.

## 10. Test plan (agent: implement with pytest)

1. rule_runtime: contract wrapping, NaN→Fail normalization, restricted namespace blocks `open`/`__import__`, compile-error surfacing.
2. engine: fixture dataset (1K rows) + 3 real converted rules (City/First Name/Surname from the design) → golden-file output comparison; failure injection at each phase asserts nothing written / partition truncated; cancel between rules.
3. output_writer: partition create/truncate idempotency; column-order assertion; COPY round-trip fidelity (delimiters, quotes, unicode in names).
4. retention: creates 5 partitions, retention_batches=3 → oldest 2 dropped.
5. summaries: weighted math + threshold band edges (rate exactly at pass_threshold → Pass; exactly at fail_threshold → Warning).
6. poller: count-file mismatch → CountMismatch, no run; stable-size guard; duplicate-trigger suppressed by unique index.

## 11. Storage Abstraction Layer (dialect portability — SQLite now, PostgreSQL later)

`worker/storage/` package, ALSO imported by the API for the pieces it needs (NameMapper, PartitionManager on activation). Four interfaces, two implementations each, selected by `DATABASE_URL` scheme (`sqlite:///...` vs `postgresql://...`). **No other module may write dialect-specific SQL for these concerns.**

### 11.1 QueueClaimer — claim the next Queued run safely
```python
class QueueClaimer(Protocol):
    def claim_next(self) -> int | None: ...       # returns run_id or None
```
- **SQLiteQueueClaimer:** `BEGIN IMMEDIATE` (takes the write lock up front) →
  `UPDATE workflow_run SET status='Running', started_at=? WHERE run_id = (SELECT run_id FROM workflow_run WHERE status='Queued' ORDER BY queued_at LIMIT 1) AND status='Queued' RETURNING run_id;` → commit. RETURNING requires SQLite ≥ 3.35 (dev has 3.45). The immediate lock + guarded WHERE makes double-claim impossible.
- **PGQueueClaimer:** `UPDATE ... WHERE run_id = (SELECT run_id FROM workflow_run WHERE status='Queued' ORDER BY queued_at LIMIT 1 FOR UPDATE SKIP LOCKED) RETURNING run_id;`
- Same for dry_run_job (claimed with priority before workflow runs).

### 11.2 BulkWriter — write the finished wide frame
```python
class BulkWriter(Protocol):
    def write(self, table: str, df: pd.DataFrame) -> int: ...   # returns rows written
```
- **SQLiteBulkWriter:** chunked `executemany` INSERTs, `WRITE_CHUNK_ROWS=500` rows/statement-batch inside one transaction (bound by SQLite's parameter limits at ~500 wide columns); dev volumes (≤100K rows) complete in seconds.
- **PGBulkWriter:** `COPY ... FROM STDIN WITH CSV` via psycopg2 `copy_expert`, streaming `to_csv` chunks of `COPY_CHUNK_ROWS=50000`.

### 11.3 PartitionManager — batch lifecycle of output tables
```python
class PartitionManager(Protocol):
    def ensure_table(self, workflow) -> None            # create output table if absent (01 §8 shape)
    def add_result_column(self, workflow, col) -> None  # ALTER TABLE ADD COLUMN (both engines)
    def prepare_batch(self, workflow, batch_date)       # SQLite: DELETE day's rows | PG: create+TRUNCATE partition
    def retire(self, workflow, retention_batches)       # SQLite: DELETE older + scheduled VACUUM | PG: DROP old partitions
    def cleanup_failed(self, workflow, batch_date)      # remove any partial write (same as prepare_batch)
```

### 11.4 NameMapper — logical → physical names
```python
class NameMapper(Protocol):
    def ref_table(self, name) -> str        # SQLite 'ref_usa_states' | PG 'dq_ref.usa_states'
    def output_table(self, wf) -> str       # SQLite 'out_wf_12_slug' | PG 'dq_output.wf_12_slug'
```

### 11.5 Dev-mode operational notes (SQLite)
- Connection bootstrap on EVERY connect: `PRAGMA foreign_keys=ON; PRAGMA busy_timeout=30000;` (WAL set once at bootstrap).
- Default `MAX_PARALLEL_RUNS=1` when `DATABASE_URL` is sqlite (single-writer engine; parallelism returns automatically on PG). The dispatcher reads this default from the dialect, overridable by env.
- Progress updates (small UPDATEs) and the bulk write share one writer — the writer batches progress updates to phase boundaries during WRITE to avoid lock churn.
- Tests in §10 run against SQLite by default; the same suite must pass against PostgreSQL when available (parametrize the DB fixture) — this is the migration insurance.
