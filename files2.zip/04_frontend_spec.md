# 04 — Frontend Specification (React, page by page)

> **Module role:** the React SPA. Depends on contract 02 (API) ONLY — it never knows the database exists. Reuses the existing shell: fixed left sidebar + main display area.
> **Agent rules — REUSE FIRST:** before writing ANY new component, inventory the existing React app and adapt: the sidebar shell, the 4-step upload wizard, the views builder pages, login form, tables/grids, and any modal/toast components are KEPT and restyled/rewired — not rebuilt. Build new only what has no existing equivalent (rule lifecycle hub, workflow designer mapping/groups logic, run progress). Record the reuse inventory in PROGRESS.md at task T16.
> Functional components + hooks; a single `api.js` client wrapping fetch with the JWT header, the {data}/{error} envelope, and 401→redirect-to-login; role checks via a `useAuth()` context exposing `hasRole('Creator')` — UI hides what the API forbids, but the API remains the enforcer. Poll `/runs/{id}/status` every 2s only while a run is Queued/Running. All result values arrive as "Pass"/"Fail" strings from the API.

## 1. Shell & navigation

Sidebar (top→bottom): **Home, Dashboard, Workflows, Views, Datasets, Rules, Issue List, User Settings, System**. User Settings and System render only for Admin. Header: app name, workspace switcher (workspaces from JWT roles), user menu (profile, logout). Every page shows a breadcrumb. Global toast component for API errors (shows `error.message`).

## 2. Login
Username + password → `POST /auth/login`. Store JWT in memory + sessionStorage-free refresh via `/auth/refresh` on 401-expiry. Failure → inline error, no detail leakage. On success → Home.

## 3. Home
Cards from `GET /summaries/home`: Active workflows, Runs today (Completed/Running/Failed with color), Groups failing today, Latest batches with load_status. Each card links to the relevant page. A "Runs in progress" strip with live progress bars (poll while visible).

## 4. Dashboard (charting module)
User picks workflow → `GET /summaries/workflows/{id}/trend?days=90` → charts: pass-rate trend per group (line, threshold bands shaded: green ≥ pass_threshold, amber between, red < fail_threshold), latest-run rule pass rates (bar, sorted ascending so worst rules lead), group status history (heat strip). Export chart data as CSV client-side. No server changes needed for new chart types — this page only reads summaries.

## 5. Datasets

**5.1 List** — `GET /datasets`: name, LOB, schedule, latest batch status chip, active workflows count. Buttons (Creator/Admin): New Dataset, Upload Lookup.

**5.2 New/Edit Dataset wizard — 4 steps (keep existing UX):**
1. *Source* — name, LOB, description, schedule_type, source_path, file_pattern, count_file_pattern, delimiter, retention_batches, workspace.
2. *Preview* — user picks a sample file (local, parsed client-side) to preview first 50 rows.
3. *Mapping* — grid of columns: name, ordinal, data type (text/int/decimal/date advisory). Prefilled from the sample header; editable.
4. *Confirm* — summary → `POST /datasets`. Edit mode: `PUT`; if API returns DATASET_IN_USE (409), show which Active workflows block column changes.

**5.3 Lookup upload wizard (same 4-step pattern):** file (CSV/XLSX) → preview → name + description + columns/datatypes → confirm → `POST /ref-datasets/upload`. If name exists, show explicit "This will OVERWRITE the existing lookup '<name>' (N rows). Rules using it pick up new values on their next run." with confirm checkbox. Lookup list page with preview drawer (`GET /ref-datasets/{id}/preview`) and deactivate (handles LOOKUP_IN_USE 409 by listing binding rules).

**5.4 Dataset detail** — metadata, column grid, batch history table (last 30: batch_date, file, expected vs actual count, status chip), linked workflows.

## 6. Rules

**6.1 Rule list** — `GET /rules`: code, name, category, LOB, current version + status chip (Draft grey, InReview blue, ApprovedUAT amber, Approved green, Retired/ Rejected muted), used-in-workflows count. Filters: status, category, text search. Button: Propose Rule (all roles).

**6.2 Propose Rule** (all roles): rule_code, rule_name, category, LOB, workspace, and a large *business definition* editor with prompts for examples: "Given value X → expected Pass/Fail". → `POST /rules`.

**6.3 Rule detail — the lifecycle hub.** Tabs:
- *Definition* — business definition, metadata, workflows using this rule.
- *Versions* — table of versions with status_history timeline. Per role, action buttons appear per 02 §2: Creator: New Version / Edit (Draft/InReview) / Submit for Review; Reviewer: Review Pass → ApprovedUAT or Reject (comment required); Approver: Approve (shows confirmation: "Version N becomes the production version; version M will be Retired"); Admin: any.
- *Code editor* (Creator) — monospace textarea for `python_expression` with the contract signature shown read-only above it; JSON editors for parameter_schema and required_columns; lookup-bindings grid (alias / ref_dataset dropdown / column dropdown from columns_json).
- *Test (dry run)* (Creator) — upload sample CSV, pick target column + parameter values → `POST .../dry-run`, poll job, render pass/fail counts + failing sample rows table. This is the UAT convenience harness.

## 7. Workflows

**7.1 List** — name, dataset, status, trigger mode, last run (status chip + batch_date + pass summary), Run button (Creator/Admin; disabled with tooltip when a run is active). New Workflow (Creator/Admin).

**7.2 Workflow designer — the core screen (Data Studio look-alike).** Header: name, description, dataset picker (locked after activation), trigger mode. Body, two panes:

- *Left pane — rule rows.* User adds rules one row at a time (searchable dropdown of Approved rules). Each rule row expands to a **dual listbox**: left = all dataset columns (from `GET /datasets/{id}`), right = selected columns; center push/pull buttons (▶ ◀ ▶▶ ◀◀). Every column on the right becomes one mapping for that rule. Per selected column: a parameters popover generated from the rule's parameter_schema (typed inputs with defaults). Rule rows are drag-reorderable; within a rule, selected-column order = right-listbox order. The flattened (rule, column) sequence defines display_order and is previewed as an ordered "Output columns" chip strip: original columns … then `R101_city`, `R101_state`, `R102_fname` …
- *Right pane — groups (layer 2).* Create groups (name, order). Drag mappings from the left into groups; per member a weight input (default 1). Per group: pass_threshold (default 99.0), fail_threshold (default 85.0), use_weighted toggle. Inline legend: "≥ pass → Pass · < fail → Fail · between → Warning".

Footer: Save Draft (`PUT mappings` + `PUT groups`), Activate (`POST activate`, confirms output-table creation), Deactivate. Validation surfacing: REQUIRED_COLUMN_MISSING names the rule + missing column; COLUMN_LIMIT_EXCEEDED shows the count; adding a rule to an Active workflow shows: "New result column(s) will be added; history shows blank for them."

**7.3 Run history & run detail.** History table per workflow (`GET /runs?workflow_id=`): batch_date, trigger, status, duration, rows. Run detail: progress section (bar + current_step, polled while live; e.g., "Executing rule 7/23: City Is Valid Check — 42%"), Cancel button (Creator/Admin), rule summary table (pass/fail counts + rate bars), group summary cards (rate, weighted rate, status color), error panel with error_message on Failed, engine-log viewer (Creator/Admin, `GET /runs/{id}/engine-log`).

## 8. Views (explore & download)

**8.1 View builder — 3 steps (mirrors Data Studio):**
1. *Dataset & Columns* — pick base: a workflow output (grouped by dataset) or a lookup table; name the view; dual listbox of available columns (`GET /workflows/{id}/output/columns`), ordered.
2. *Rows & Filter* — All rows vs Limit N; filter rows builder: column / operator (=, ≠, >, <, ≥, ≤, contains, in, is null, not null) / value; for workflow outputs a batch_date range control (default: latest batch) — required unless "all batches" explicitly ticked.
3. *Profile & Save* — live preview (first 100 rows via `POST /explore/query`) + quick profile of selected columns (non-empty %, distinct count — computed client-side on the preview page only, labeled "sample profile"); then Save (`POST /views`), Download (`.../download`), or both.

**8.2 View list** — my views + workspace views; Run (paginated grid), Edit, Download CSV, Delete (owner/Admin). Pass/Fail cells color-chipped in all grids.

## 9. Issue List
Operational problems in one queue, newest first: Failed runs (error_message, link to run detail), CountMismatch batches, workflows Active but skipped (no batch arrived by expected time — client-side derivation from batch history). Filter by workspace/dataset. Row action for Creator/Admin: Re-run (`POST /workflows/{id}/runs`).

## 10. User Settings (Admin)
Users grid (`/admin/users`): activate/deactivate, edit roles dialog — matrix of role × workspace checkboxes → `PUT /admin/users/{id}/roles`. Read-only reminder banner: "Authentication is corporate AD/SSO; only roles are managed here."

## 11. System (Admin)
- *Queue monitor* — `GET /admin/queue`: live table of Queued/Running runs with progress bars.
- *Audit browser* — `GET /admin/audit` with filters (user, action, date range), paginated.
- *Environment card* — API health (`/health`), version strings.

## 12. Cross-cutting UI rules
Pass = green chip, Fail = red, Warning = amber — consistent everywhere. Every destructive/irreversible action (overwrite lookup, activate workflow, cancel run, delete view) uses an explicit confirmation dialog stating the consequence. Tables: server-side pagination, column sort where API supports it. Empty states explain the next action ("No rules yet — propose one"). All timestamps rendered in the user's locale with UTC tooltip.

---

## 13. Wireframes (ASCII) — key screens in detail

Reference inspiration: Aperture Data Studio screenshots (grid toolbar, Jobs tracker, role-permission matrix, step-card workflow canvas). Our equivalents below. Legend: `[Button]`, `(o) radio`, `[x] checkbox`, `▼ dropdown`, `┃` pane divider.

### 13.1 Rule creation — Propose (business user, any role)

```
┌─ Rules ▸ Propose New Rule ──────────────────────────────────────────────┐
│ Rule Code*  [R151        ]   Rule Name* [Account Status Is Valid     ]  │
│ Category*   [Lookup    ▼]    LOB [Cards ▼]   Workspace [Cards-WS ▼]     │
│ Expected Data Type [text ▼]                                             │
│ ── Business Definition* ───────────────────────────────────────────────│
│ │ The account status code must exist in the approved status list.    │ │
│ │ Examples:                                                          │ │
│ │   value "11"  → Pass          value "XX" → Fail                    │ │
│ │   value ""    → Fail          value "97" → Pass                    │ │
│ ────────────────────────────────────────────────────────────────────── │
│                                   [Cancel]  [Submit Proposal]           │
└──────────────────────────────────────────────────────────────────────────┘
→ POST /rules → creates rule + version 1 (Draft) → appears in Reviewer queue.
```

### 13.2 Rule detail — lifecycle hub (tabs; actions render by role)

```
┌─ Rules ▸ R151 · Account Status Is Valid ──────────── status: ● InReview ┐
│ [Definition] [Versions] [Code Editor] [Test (Dry Run)]                  │
│──────────────────────────────────────────────────────────────────────── │
│ VERSIONS tab                                                             │
│  Ver  Status       By          At                Actions (role-gated)   │
│  v2   InReview     s.kumar     2026-07-14 09:12  [Review Pass][Reject]  │← Reviewer
│  v1   Retired      s.kumar     2026-05-02 11:40  (view only)            │
│  Timeline: Draft→InReview (s.kumar) → …status_history rendered here…    │
│──────────────────────────────────────────────────────────────────────── │
│ CODE EDITOR tab (Creator; editable only in Draft/InReview)               │
│  def evaluate(df, column, lookups, params):   ← contract, read-only      │
│  ┌────────────────────────────────────────────────────────────────────┐ │
│  │ return df[column].astype(str).str.strip().isin(                  │ │
│  │     lookups["valid_status"].astype(str).str.strip())             │ │
│  └────────────────────────────────────────────────────────────────────┘ │
│  Parameters schema (JSON) [ {} ]      Required columns (JSON) [ [] ]    │
│  Lookup bindings:  alias [valid_status] ref table [Acct Status ▼]       │
│                    column [code ▼]                     [+ Add binding]  │
│                                    [Save Draft] [Submit for Review]     │
│──────────────────────────────────────────────────────────────────────── │
│ TEST tab (Creator): [Upload sample CSV] column [status ▼] params {…}    │
│  [Run Dry Test] → Passed 9,742 · Failed 258 · Failing sample (20 rows)  │
└──────────────────────────────────────────────────────────────────────────┘
```

### 13.3 Workflow designer — configure mappings & groups

```
┌─ Workflows ▸ Cards Daily DQ ──────────────────────────── status: Draft ─┐
│ Dataset [ACCT_MASTER ▼(locked when Active)]  Trigger (o)Auto ( )Manual  │
│ ┌─ SUMMARY BAR (live) ────────────────────────────────────────────────┐ │
│ │  Rules: 12   Mappings: 34   Groups: 3   Output columns: 250+3+34=287│ │
│ └──────────────────────────────────────────────────────────────────────┘ │
│──────────────────────────── two panes ──────────────────────────────────│
│ RULE MAPPINGS (ordered, drag ↕)      ┃  RULE GROUPS (layer 2)           │
│ ▸ 1. R101 City Is Valid       [x]    ┃  ▾ Identity Quality  (order 1)   │
│    Available columns  Selected       ┃     pass ≥ [99.0]  fail < [85.0] │
│    ┌───────────┐ ▶  ┌───────────┐    ┃     weighted [x]                 │
│    │ acct_no   │ ▶▶ │ city      │    ┃     members:                     │
│    │ fname     │ ◀  │ mail_city │    ┃      R101_city        w[1  ]     │
│    │ state     │ ◀◀ └───────────┘    ┃      R102_fname       w[2  ]     │
│    └───────────┘   params(city){…}   ┃      R102_sname       w[1  ]     │
│ ▸ 2. R102 First Name Is Valid [x]    ┃  ▸ Address Quality   (order 2)   │
│    …dual listbox per rule…           ┃  ▸ Account Codes     (order 3)   │
│ [+ Add Rule ▼ (Approved only)]       ┃  [+ Add Group]                   │
│──────────────────────────────────────────────────────────────────────── │
│ Output column preview (order locked to mappings):                        │
│  rec_id·batch_date·run_id·acct_no…state │ R101_city R101_mail_city …    │
│                     [Save Draft]  [Activate ▸ creates output table]      │
└──────────────────────────────────────────────────────────────────────────┘
Validation toasts: REQUIRED_COLUMN_MISSING("R102 needs column 'mname'"),
COLUMN_LIMIT_EXCEEDED, PARAM_SCHEMA_MISMATCH — surfaced inline at the row.
```

### 13.4 Workflow read view — step-card strip (Aperture-canvas feel, read-only)

```
┌─ Cards Daily DQ ─────────────── ● Active · last run Completed 06:12 ────┐
│ ┌──────────────┐   ┌────────────────┐   ┌──────────────┐   ┌──────────┐ │
│ │ SOURCE        │→ │ RULES          │→ │ GROUPS        │→ │ OUTPUT    │ │
│ │ ACCT_MASTER   │  │ 12 rules       │  │ 3 groups      │  │ out_wf_12 │ │
│ │ daily · NDM   │  │ 34 mappings    │  │ thresholds set│  │ 287 cols  │ │
│ │ 500K rows/day │  │ [view list]    │  │ [view]        │  │ 90 batches│ │
│ └──────────────┘   └────────────────┘   └──────────────┘   └──────────┘ │
│ [Run Now] [Edit] [Deactivate]        Runs: [history table below]        │
└──────────────────────────────────────────────────────────────────────────┘
```

### 13.5 Jobs page (global run tracker — mirrors Aperture "Jobs")

Sidebar gets a **Jobs** item (all roles, read; Creator/Admin get actions). This is the cross-workflow view; per-workflow history stays on the workflow page.
```
┌─ Jobs ── filter [workflow ▼][status ▼][date range] ─────────────────────┐
│ Workflow        Space    Initiated by  Status     Start      Elapsed    │
│ Cards Daily DQ  Cards    system(auto)  ▓▓▓▓░ 64%  06:10:02   00:02:41 ⋮ │
│ Loans Daily DQ  Loans    r.patel       Completed  06:05:11   00:03:58 ⋮ │
│ Deposits Month  Deposits system(auto)  Failed ⚠   06:01:00   00:00:12 ⋮ │
│  └ error: Rule 'State Code Valid' on 'state': KeyError 'state'          │
│ ⋮ menu: View run · Cancel (if live) · Re-run · Engine log (Creator+)    │
└──────────────────────────────────────────────────────────────────────────┘
```

### 13.6 Role permissions page (System ▸ Roles — mirrors Aperture matrix)

Read-only matrix of the five fixed roles vs capabilities (from 02 §2), with per-user assignment done in User Settings. We intentionally do NOT support custom roles in v1 — the matrix page displays the fixed policy so Admins can communicate it, exactly like Aperture's Role permissions screen but without editing per-cell.

### 13.7 Output grid (Views ▸ run) — toolbar echoes Aperture's grid

```
[Filter] [Columns] [Sort] [Download CSV]        batch_date [2026-07-14 ▼]
─ grid: original cols … │ R101_city:  Pass ▣ / Fail ▣ (green/red chips) ─
footer: 500,000 rows · 287 columns · page 1/1000
```
Profile/Sample/Group/Transform from Aperture are OUT of scope v1 (the "sample profile" on the view-builder preview covers the profiling need lightly).
