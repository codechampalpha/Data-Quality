# 00 — System Overview: In-House Data Quality Platform

> **HOW TO USE THIS DOCUMENT SET (read first, every session)**
> This is one of six spec files. Load this file into every agent session, plus ONLY the module file(s) for the task at hand (see 05_build_plan.md §Token Protocol).
> **Rule for the agent:** implement only what the loaded module spec describes. Never modify code belonging to another module. Cross-module needs are satisfied exclusively through the two contracts: the database schema (01) and the REST API (02). If a task appears to require changing a contract, STOP and report the required contract change instead of making it silently.

## 1. Purpose

Internal replacement for Experian Data Studio. Business defines data-quality rules in plain English; the technical team implements them as Python (pandas) expressions; approved rules are mapped to columns of registered datasets inside workflows. Daily (or monthly) input files are validated by a rule engine; output = original data + one Pass/Fail column per rule-column mapping, retained ~90 days, plus weighted group scores with per-workflow thresholds. Users explore/download results through a React portal under role-based access.

## 2. Architecture

```
React SPA (nginx pod) ──HTTPS/JWT──▶ API Service (Flask) ──SQL──▶ Database
                                                                   ▲ DEV: SQLite file (dq_platform.db, WAL mode)
Worker Service (plain Python) ────────────────SQL──────────────────┘ PROD: PostgreSQL 15+ (dq_meta/dq_ref/dq_output)
   │  polls NDM shared path (read-only mount) for daily files + count files
   └  executes workflow runs (pandas rule engine), writes output partitions/batches
```

Three OpenShift deployments (dev: can run as three local processes on the Mac's OpenShift/CRC or plain terminals). API and Worker NEVER call each other — they coordinate only through database tables (`workflow_run` acts as the job queue). Frontend talks only to the API. The database engine (SQLite now, PostgreSQL later) is swappable because all dialect-sensitive operations live behind the storage abstraction layer (03 §11).

## 3. Technology stack (all confirmed in company Artifactory)

| Layer | Technology |
|---|---|
| Database (DEV, now) | **SQLite 3.40+** — single file, zero install; WAL mode; JSON1; partial indexes |
| Database (PROD, later) | **PostgreSQL 15+** — declarative partitioning, JSONB, COPY. Migration path is designed-in from day one (see 01 §1 and §10) |
| DB portability rule | ALL database access goes through the **storage abstraction layer** (03 §11): QueueClaimer, BulkWriter, PartitionManager, NameMapper. Application code never writes dialect-specific SQL for these four concerns |
| API | Python, Flask 3.0, Flask-CORS 4.0 |
| Auth | ldap3 2.9 (AD/SSO authentication) + PyJWT 2.9 + cryptography 43 |
| DB access | SQLAlchemy core + sqlite3 driver now / psycopg2 later (both behind the same db module) |
| Engine | pandas 2.2 + numpy (worker is a plain Python process, no web framework) |
| Excel intake | openpyxl 3.1 / xlrd 2.0 (lookup-table uploads) |
| Job queue | `workflow_run` table; claim semantics per dialect (03 §11) |
| Frontend | React SPA — **REUSE the existing app**: shell/sidebar, 4-step upload wizard, views pages, login. New screens only where no equivalent exists (04 §0) |

## 4. Module boundaries and ownership

| Module | Spec file | Owns | Reads contracts | Must never touch |
|---|---|---|---|---|
| Database | 01_database_schema.md | All DDL, migrations | — | — |
| API | 02_api_spec.md | Flask app, auth, RBAC, all endpoints | 01 | Worker code, React code |
| Worker | 03_worker_spec.md | Poller, dispatcher, rule engine, retention | 01 | Flask code, React code |
| Frontend | 04_frontend_spec.md | All React pages/components | 02 only | Database, Python |

## 5. Core domain concepts (glossary)

- **Dataset** — a registered input feed (CSV via NDM path; ~500K rows/day, ~250 columns; some monthly). Described by expected columns; each arrival is a **batch** identified by `batch_date`.
- **Reference/Lookup dataset** — a small table of allowed/invalid values, uploaded by Admin through a wizard (CSV or Excel). Lives as a physical table in schema `dq_ref`, registered in `ref_dataset`. Re-upload overwrites content; NO rule re-approval needed when content changes.
- **Rule** — stable business object (`rule_code` like `R101`, unique name, plain-English definition). Its executable code lives in **rule_version** rows that move through: Draft → InReview → ApprovedUAT → Approved → Retired/Rejected. Exactly ONE Approved version per rule (DB-enforced). Only Approved versions execute in production.
- **Rule contract** — every rule's code is the body of `evaluate(df, column, lookups, params) -> boolean Series` (True=Pass). See 03 §3.
- **Workflow** — dataset + ordered list of (rule, column) **mappings** (each with optional per-mapping parameters) + **rule groups** (weighted, with pass/fail thresholds) + a dedicated wide **output table**.
- **Run** — one execution of a workflow against one batch. Statuses: Queued → Running → Completed/Failed/Cancelled. All-or-nothing: any rule error fails the whole run and nothing is written.
- **Output table** — one per workflow, wide: rec_id, batch_date, run_id, all original columns, then one `CHAR(1)` ('P'/'F') column per mapping named `{rule_code}_{column}`. Batch-managed by the PartitionManager: PROD/PostgreSQL = RANGE partitions per batch_date (retention = drop partition, overwrite = truncate partition); DEV/SQLite = single table (retention/overwrite = `DELETE WHERE batch_date ...`). Default retention 90 daily / 3 monthly batches, per-dataset configurable.
- **rec_id** — `batch_id * 10^9 + row_number` (BIGINT). Row_number = position in the source file. Deterministic, idempotent on re-run, and doubles as the join key for validating against Experian output (both systems process the identical file in order).
- **View** — saved user query over an output/dataset table: selected columns + filters + row limit; runnable and downloadable as CSV.
- **Roles** — Admin, Creator, Approver, Reviewer, Explorer. Authentication = AD/SSO via ldap3; authorization = local `user_role` table (workspace-scoped). Full capability matrix in 02 §2.

## 6. Non-negotiable system rules (apply across ALL modules)

1. Single-write principle: raw input is never pre-loaded into output tables. The worker computes everything in memory, then writes the finished partition once.
2. Same-day re-run = overwrite: truncate that day's partition, regenerate identical rec_ids.
3. A workflow can never have two active (Queued/Running) runs — DB unique index enforces it. Different workflows may run in parallel (start: 2 workers).
4. Any rule error → whole run Failed, error recorded, nothing persisted to output.
5. Pass/Fail only in v1; the rule contract and engine internals are shaped so a future `fail_reason` needs no schema/rule rewrites.
6. Count file must match actual row count before processing (NDM completeness check).
7. Column order in output = source column order, then mapping `display_order`.
8. No PII in logs, `engine_log`, or error messages — log rule names and counts, never data values.
9. All user-facing SQL (views/filters) is parameterized server-side. Never interpolate user input into SQL.
10. Every security-relevant action (rule approval, run trigger, download) is written to `audit_log`.
11. Dialect neutrality: no module writes SQLite-only or PostgreSQL-only SQL for queue claiming, bulk writes, batch retention/overwrite, or physical table naming — those four go through the storage abstraction layer (03 §11). Everything else uses the portable SQL subset defined in 01 §1.

## 7. Environment

- DEV (now): developer machines + OpenShift Local/CRC on the office Mac. Database = a single SQLite file per environment (`data/dq_platform.db`), WAL mode, created by the bootstrap script. Sample volumes (1K–100K rows) — SQLite is comfortable here.
- PROD (later): OpenShift (Kubernetes) on corporate cloud; 8-core / up to 128 GB RAM to start; PostgreSQL 15+ on PVC-backed encrypted storage (plan 1.5–2.5 TB). Migration is a scripted, one-time exercise (01 §10) — schema DDL translation + data pump + flip of `DATABASE_URL`.
- NDM shared path mounted read-only into the Worker pod (dev: any local folder set via `NDM_ROOT`).
- Source system is Big Data (PySpark) — read-only for us; future direct Impala connection is anticipated (`dataset.source_type='impala'`) but NOT in scope for v1.
- Secrets (DB creds, JWT signing key, LDAP bind) in OpenShift Secrets (dev: `.env` file, git-ignored).

## 8. Scale assumptions (design targets)

6 LOBs, ~25 datasets, ~150 rules, ~250 columns per dataset, 500K rows/day per daily dataset, 90-day retention. One batch in memory ≈ 1–2 GB as pandas strings; wide output write via COPY ≈ under a minute. Per-record-per-rule result rows are FORBIDDEN (would be 75M rows/day) — verdicts live only in the wide output; aggregates live in small summary tables.
