# 07 — Walkthrough: How the Platform Works, Evolves, and Why

> **Audience:** you (Data Analytics / SQL expert, learning React & Python) and your Tech Manager. This document has no agent instructions — it's the narrative that connects the other six specs. Read it before any design discussion; lend it to teammates joining the project.

## 1. The one-paragraph pitch

We are replacing Experian Aperture Data Studio's data-quality validation with an in-house platform: business writes rules in English, our tech team implements each as a small pandas expression, approved rules are mapped to dataset columns inside workflows, and every day when the source file lands, an engine executes the rules and produces the original data plus a Pass/Fail column per rule-column — with weighted group scores on top, 90 days of history, dashboards, downloadable views, and full role-based governance. Open-source stack end to end: React, Flask, pandas, SQLite now → PostgreSQL at production.

## 2. The life of one day's data (follow a single file end to end)

1. **06:00 — the file lands.** The Big Data team's PySpark job drops `ACCT_MASTER_20260715.csv` (500K rows, ~250 columns) and `ACCT_MASTER_20260715.cnt` (row count) on the NDM shared path. We only ever read this path.
2. **06:01 — the Worker notices.** A poller loop checks every ~90 seconds. It sees both files, waits until the data file's size is stable (still-copying guard), reads the count file, and registers a **batch** row (dataset + date, unique — a re-sent file the same day reuses the same batch and means "overwrite").
3. **06:02 — runs are queued.** For every Active workflow on that dataset with auto-trigger, the Worker inserts a `workflow_run` row with status Queued. The database itself refuses a second active run for the same workflow (a partial unique index) — that's how "no overlap" is guaranteed without any locking code.
4. **06:02 — a run is claimed.** The dispatcher picks the oldest Queued run using a dialect-safe claim (on SQLite: an immediate-lock transaction; on PostgreSQL: `FOR UPDATE SKIP LOCKED`). Status → Running; the UI progress bar starts moving because the frontend polls a tiny status endpoint every 2 seconds.
5. **06:02–06:03 — validate everything before touching data.** The engine checks: count file matches actual rows; every mapped rule has exactly one Approved version; every secondary column a rule needs (e.g., First Name rule reads `mname`) exists; every lookup binding points to a live reference table. Any problem → the run fails *now* with a precise message, and nothing has been written. It also snapshots exactly which rule version IDs will run — the audit answer to "what code produced these results?"
6. **06:03 — load.** The CSV is read into pandas with everything as strings (no silent type coercion), a `rec_id` is stamped on every row (`batch_id × 10⁹ + row position` — deterministic, so a re-run reproduces identical IDs), and each needed lookup table is pulled into memory once.
7. **06:03–06:05 — rules execute.** Each rule's stored Python body is compiled into a function `evaluate(df, column, lookups, params)` inside a restricted namespace (pandas/numpy/re only — a guardrail against accidents, since only trusted, UAT-tested code reaches Approved). Mappings run in the order defined in the workflow; each returns True/False per row, converted to 'P'/'F'. After every rule the progress bar and "Executing rule 7/23: City Is Valid Check" update. **If any rule throws, the whole run fails and nothing is written** — an all-or-nothing day.
8. **06:05 — one atomic-feeling write.** Only now does the engine touch the output table: it clears any existing rows for this batch date (that's the overwrite), then bulk-writes the finished wide frame — originals + result columns — in one pass (chunked inserts on SQLite; COPY on PostgreSQL). Because computation finished *before* writing, a failure can never leave half a day in the table.
9. **06:05 — summaries & layer 2.** Per rule-column: pass/fail counts and rate into `run_rule_summary`. Per group: weighted pass rate = Σ(weight × passed) / Σ(weight × total), compared to the workflow's thresholds (e.g., ≥99% Pass, <85% Fail, Warning between) into `run_group_summary`. These small tables are what dashboards read — never the 45M-row output.
10. **06:05 — retention.** Rows older than the retention window (90 daily batches; monthly feeds keep e.g. 3) are removed — a DELETE on SQLite, an instant partition drop on PostgreSQL.
11. **06:06 — done.** Run → Completed, batch → Processed. Explorers open Views, filter to today, see green/red chips, download CSV; the Dashboard trend adds today's point; anything that failed appears on the Issue List.

## 3. The life of one rule (governance in four steps — who does what)

1. **Propose (anyone).** A business user writes the rule in plain English with examples ("status must exist in the approved list; '11'→Pass, 'XX'→Fail"). This creates the rule and version 1 in Draft.
2. **Review (Reviewer).** Reviewer reads the definition, asks questions via comments, and either rejects (back to Draft) or passes it toward implementation.
3. **Implement & test (Creator = tech team).** Creator writes the Python body in the rule's code editor, declares parameters (e.g., min_length) and secondary columns, binds lookup tables (each lookup bound to one column, one rule may use many lookups), and dry-runs it against a sample CSV right in the UI. After UAT sign-off the version sits at ApprovedUAT.
4. **Approve (Approver = business).** One click makes it the production version — and the same transaction retires the previous Approved version, so exactly one version of a rule can ever run. Every transition lands in `status_history` and the audit log.

Key consequence you can quote to anyone: **workflows reference the rule, not the version** — the Approved version is resolved at run time. Approving v3 tonight means tomorrow's runs use v3 automatically, everywhere, with the version snapshot recorded per run.

## 4. Why these design decisions (the "defend it in a meeting" list)

- **Wide output table (one column per rule-column) instead of one row per record-per-rule.** Users consume results as "my data + verdict columns" — one SELECT, no pivots. The row-per-result alternative would create 500K × 150 = 75M rows *per day*; the demo proved the pain. Aggregates live in small summary tables instead.
- **Compute-then-write (single write).** No half-processed data ever visible; failed runs clean up trivially; re-runs are idempotent because rec_ids are positional.
- **SQLite now, PostgreSQL later — safely.** PostgreSQL isn't provisioned yet, so all development runs on a single SQLite file (WAL mode). The migration risk is contained by two disciplines written into every spec: a portable SQL subset everywhere, and a four-interface storage layer (queue claim, bulk write, batch overwrite/retention, physical naming) that is the *only* place dialect-specific code may exist. Cutover = translate DDL by a fixed type table, pump data, flip `DATABASE_URL`, and the same test suite runs against both engines as insurance. We can rehearse the whole thing on the office Mac's OpenShift Local with a containerized PostgreSQL before real PROD exists.
- **Per-workflow thresholds, not a hardcoded formula.** "Pass at ≥99%, Fail below 85%" differs by workflow — so thresholds are columns on the group, set in the designer, and the engine just compares.
- **In-memory dynamic code, logged for audit.** No `ruleengine.py` files on disk to manage; the generated source of every rule that ran is stored in the run's engine log — reviewable, never containing data values (PII rule).
- **DB as the queue.** One fewer moving part than Celery/Redis; the claim semantics are proven per dialect; parallelism (2 workflows) arrives with PostgreSQL, while SQLite runs one at a time — fine for dev volumes.
- **Reuse over rewrite.** Existing React shell, upload wizard, views pages, Flask/JWT/ldap3 plumbing are kept and adapted; the genuinely new parts are the schema, the worker engine, the rule lifecycle screens, and the workflow designer logic.

## 5. How the app evolves (phases in one view)

| Phase | You get | Proof point |
|---|---|---|
| 1 Foundation | SQLite schema + storage layer + **engine runs your 3 real rules end to end** on a fixture file | Golden-file match; broken rule writes nothing |
| 2 Automation | File watcher, count check, queue, progress bar, cancel/timeout | Drop a file → run happens by itself |
| 3 API | Full REST surface with RBAC + audit | Every capability in the matrix enforced server-side |
| 4 Frontend | All screens (wireframes in 04 §13), reusing the existing app | Designer shows "12 rules · 34 mappings · 287 output columns" live |
| 5 Cutover | 150-rule migration, Experian comparison utility, OpenShift deploy, PG migration when DB arrives | Parallel window with zero unexplained mismatches → decommission Aperture |

## 5b. Moving objects between environments (how UAT work reaches PROD)

Instead of copy-pasting rule code between environments, an Admin exports a workspace: the platform builds a zip containing a manifest plus one JSON file per object — workflows, rules (with full version history), datasets, lookup datasets (including their data rows), optionally views. Every reference inside those JSONs uses the object's UUID plus its natural key, never local database ids, so the target environment can match reliably. Import is three deliberate steps: upload → preview (a plan showing exactly what would be Created, Updated, Skipped-identical, or is in Conflict) → apply, in dependency order (lookups → datasets → rules → workflows). Imported new workflows arrive as Draft — activating them (and creating their output table) stays a conscious local decision. Every applied object writes an `Import metadata` audit event; the whole exercise is reconstructable later. One governance dial exists: imported rule versions can arrive as-exported (Approved stays Approved — the streamlined promotion you use today) or demoted to ApprovedUAT so the PROD Approver must re-approve — choose per import.

## 5c. The audit trail (what an auditor receives)

Every meaningful action — login, rule created/approved, workflow activated, run triggered, file downloaded, metadata exported/imported — becomes one event with a category (EventType), a specific Operation, a readable Message, and the typed target object with its UUID. The audit browser filters by any of these, and Download CSV produces the exact 13-column layout your auditors already consume from DataArc (SpaceName, UserId, UserName, EventType, Operation, EventDate, Message, TargetObjectType, TargetObjectName, SessionId, EventId, TargetObjectId, TargetObjectUuid) — so the audit process survives the tool replacement unchanged.

## 6. Aperture concept → our equivalent (translation table for the team)

| Aperture Data Studio | Our platform |
|---|---|
| Spaces | Workspaces (role assignments are workspace-scoped) |
| Datasets | Datasets page + registration wizard (NDM-fed) |
| Views (columns/rows/filter) | Views module — same 3-step builder, CSV download |
| Workflows (step canvas) | Workflow designer (mapping + groups) + read-only step-card strip |
| Validate-x steps | Rules (each a pandas expression) applied per column |
| Jobs page | Jobs page — global run tracker with progress, elapsed, actions |
| Schedules | Auto-trigger on file arrival (+ manual Run); cron-style schedules only if ever needed |
| Role permissions matrix | System ▸ Roles matrix (five fixed roles, read-only policy display) |
| Audit events / export | Audit browser + Download CSV in identical 13-column layout |
| Export/Import metadata (zip of JSONs) | System ▸ Export/Import wizard — same zip-of-JSONs shape, uuid-matched |
| Functions / Transform / Profile | Out of scope v1 (light "sample profile" exists in the view builder) |

## 7. For your own ramp-up (React & Python, honestly scoped)

You don't need deep React/Python to steer this project — you need to read four shapes. **Python:** a rule is just a function body returning a True/False column; pandas works on whole columns at once (`df["city"].str.len() > 1` evaluates 500K rows in one line — that's why 150 rules finish in seconds). The worker is a loop: claim → validate → load → execute → write → summarize. **Flask:** each endpoint is a small function with a decorator (`@app.route(...)` + `@require_role(...)`) that reads JSON, runs SQL, returns JSON — your SQL expertise carries 80% of the API. **React:** a page is a function returning HTML-ish markup; `useState` holds what's on screen; the app talks to Flask through one shared `api.js`. **SQL:** you already own the hardest part — the schema, the partial unique indexes doing governance work, and the summary queries are pure SQL thinking.

## 8. Questions your Tech Manager will ask — and the answers

- *"What if a rule has a bug in production?"* The run fails loudly, nothing is written, the Issue List and error message name the rule; Creator fixes, re-runs the day. History never contains bad verdicts.
- *"How do we know exactly what produced last Tuesday's results?"* `rule_versions_used` on the run + the generated source in the engine log + immutable version history.
- *"Can two people's changes collide?"* Rule editing is locked after InReview; only one Approved version can exist (DB-enforced); workflow mapping saves are replace-all with validation; runs can't overlap per workflow (DB-enforced).
- *"What's the PostgreSQL migration risk?"* Bounded by design: portable SQL subset + four-interface storage layer + the same test suite green on both engines + a rehearsal on OpenShift Local before PROD (01 §10, 03 §11, task T26b).
- *"How do we prove parity with Experian?"* The comparison utility joins on file row position (both systems process the identical file) and reports per-rule mismatches; cutover requires an agreed parallel window at zero unexplained mismatches.
- *"PII exposure?"* AD/SSO auth, workspace-scoped roles, downloads audited with row counts, no data values in any log, encrypted storage at PROD, masking for Explorers is a designed-in later option.
