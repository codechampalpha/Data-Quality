# PROGRESS.md — Live Project State (update at the end of EVERY session)

Last session: (date) · (task worked) · (by)

## How to read this file
Board statuses: ☐ not started · ◐ in progress (see Resume TODO) · ☑ done (acceptance passed) · ⊘ blocked (see note).
This file is the agent's memory between sessions. Keep entries terse.

## Task board (from specs/05_build_plan.md)
| ID | Task | Status | Notes |
|---|---|---|---|
| T0  | Scaffold repo layout | ☐ | |
| T1  | SQLite bootstrap schema | ☐ | |
| T1b | Storage abstraction layer | ☐ | |
| T2  | Sample fixtures + 3 seed rules | ☐ | |
| T3  | Rule runtime (contract, safe exec) | ☐ | |
| T4  | Engine core end-to-end (MILESTONE) | ☐ | |
| T5  | Retention & overwrite proof | ☐ | |
| T6  | Poller (NDM watcher + count file) | ☐ | |
| T7  | Dispatcher & parallelism | ☐ | |
| T8  | Cancel + timeout + engine_log | ☐ | |
| T9  | Auth & RBAC skeleton | ☐ | |
| T10 | Datasets + lookups endpoints | ☐ | |
| T11 | Rules lifecycle endpoints | ☐ | |
| T12 | Workflows endpoints | ☐ | |
| T13 | Runs endpoints | ☐ | |
| T14 | Explore/views/downloads/summaries/admin | ☐ | |
| T14b| Audit event model + DataArc CSV download | ☐ | |
| T15 | Dry-run job path | ☐ | |
| T16 | Frontend reuse audit + shell | ☐ | reuse inventory goes below |
| T17 | Home + Dashboard | ☐ | |
| T18 | Datasets pages + wizards | ☐ | |
| T19 | Rules pages (lifecycle hub) | ☐ | |
| T20 | Workflow designer | ☐ | split: left pane / right pane / save |
| T21 | Run history + live progress | ☐ | |
| T22 | Views builder + downloads | ☐ | |
| T23 | Issue List / User Settings / System | ☐ | |
| T23b| Export/Import environment transfer | ☐ | |
| T24 | 150-rule migration loader | ☐ | |
| T25 | Experian comparison utility | ☐ | |
| T26 | Deployment (OpenShift Local parity) | ☐ | |
| T26b| PostgreSQL migration (when DB exists) | ⊘ | blocked on PROD PG |
| T27 | Parallel-run window (operational) | ⊘ | after cutover readiness |

## Resume TODO (for the in-progress task)
- (empty)

## Frontend reuse inventory (filled during T16)
| Existing component/page | Decision (keep / adapt / replace) | Target spec section |
|---|---|---|
| | | |

## Decisions log (small choices made during implementation)
- (date) — (decision) — (reason)

## Contract Change Requests (schema 01 / API 02) — NEVER implement before approval
| # | Date | Requested change | Rationale | Affected modules | Status (proposed/approved/applied) |
|---|---|---|---|---|---|
| | | | | | |

## Deviations from spec (should be rare; each needs a reason)
- (none)
