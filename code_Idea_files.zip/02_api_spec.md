# 02 — API Specification (Contract #2 + Flask implementation spec)

> **Module role:** the only interface the Frontend may use, and the only writer of dq_meta on behalf of users. Reads contract 01. Never contains rule-engine logic (Worker's job) and never renders UI.
> **Agent rules:** Flask 3.0 + Flask-CORS; SQLAlchemy core + psycopg2; all endpoints under `/api/v1`; JSON in/out; JWT bearer auth on everything except `/auth/login` and `/health`. Repo layout: `api/app.py`, `api/auth.py`, `api/rbac.py`, `api/routes/<domain>.py`, `api/db.py`, `api/services/<domain>.py`. Parameterized SQL only.

## 1. Cross-cutting conventions

- **Envelope:** success → `{"data": ..., "meta": {...}}`; error → `{"error": {"code": "RULE_NOT_FOUND", "message": "...", "details": {}}}` with proper HTTP status (400 validation, 401 unauthenticated, 403 forbidden, 404, 409 conflict, 500).
- **Pagination:** list endpoints accept `?page=1&page_size=50` (max 500); `meta` returns `{"page","page_size","total"}`. Filtering via documented query params; sorting via `?sort=field&order=asc|desc`.
- **Audit:** every mutating endpoint writes `audit_log` in the same transaction.
- **Workspace scoping:** every list/read is filtered to workspaces where the caller holds any role; Admin sees all.

## 2. Authentication & RBAC

`POST /auth/login {username, password}` → ldap3 bind against corporate AD (server/base-DN from env). On success: upsert `app_user`, load roles from `user_role`, issue JWT (PyJWT, HS256 or RS256 via cryptography; 8h expiry) with claims `{sub, name, roles: [{role, workspace}], exp}`. → `{token, user:{username, display_name, roles}}`.
`POST /auth/refresh` (valid token → new token). `GET /auth/me` → profile + roles.
Note: authentication is AD/SSO; authorization is ALWAYS the local user_role table — AD groups do not map to roles automatically.

Decorator `@require_role('Creator','Admin')` guards each route (Admin implicitly passes all checks). Capability matrix (single source of truth — Frontend mirrors it for visibility only; API enforces it):

| Capability | Admin | Creator | Approver | Reviewer | Explorer |
|---|---|---|---|---|---|
| Manage users/roles/system | ✔ | | | | |
| Datasets & lookup uploads (create/edit) | ✔ | ✔ | | | |
| Propose rule (English definition) | ✔ | ✔ | ✔ | ✔ | ✔ |
| Review rule (InReview→ApprovedUAT / Rejected) | ✔ | | | ✔ | |
| Approve rule (ApprovedUAT→Approved) | ✔ | | ✔ | | |
| Author rule code / versions | ✔ | ✔ | | | |
| Create/edit/activate workflows | ✔ | ✔ | | | |
| Trigger/cancel runs | ✔ | ✔ | | | |
| Views: create/save/download | ✔ | ✔ | ✔ | ✔ | ✔ |
| Read rules/workflows/runs/summaries | ✔ | ✔ | ✔ | ✔ | ✔ |

## 3. Endpoints by domain

### 3.1 Datasets `/datasets`
- `GET /datasets` — list (filters: lob, schedule_type, is_active).
- `POST /datasets` — create registration: `{dataset_name, lob, description, schedule_type, source_path, file_pattern, count_file_pattern, delimiter, retention_batches, workspace, columns:[{column_name, ordinal_position, data_type}]}`.
- `GET /datasets/{id}` — detail incl. columns and latest batches.
- `PUT /datasets/{id}` — update metadata/columns (column changes allowed only while no Active workflow uses the dataset; else 409).
- `GET /datasets/{id}/batches?limit=30` — recent `dataset_batch` rows with load_status.

### 3.2 Reference/lookup datasets `/ref-datasets`
- `GET /ref-datasets` — list.
- `POST /ref-datasets/upload` — multipart wizard finalization: file (CSV/XLSX — openpyxl/xlrd) + `{name, description, columns:[{name, data_type}], workspace}`. Behavior: sanitize physical name; if `name` exists → TRUNCATE + reload + update row_count/loaded_at (overwrite semantics, Admin/Creator only); else CREATE TABLE in dq_ref + register. Returns registration + row_count.
- `GET /ref-datasets/{id}/preview?limit=100` — sample rows.
- `DELETE /ref-datasets/{id}` — soft-deactivate; 409 if any Approved rule_version binds it.

### 3.3 Rules `/rules`
- `GET /rules` — list with current-version status, category, lob (filters: status, rule_type_id, q).
- `POST /rules` — propose: `{rule_code, rule_name, rule_type_id, business_definition, expected_data_type, lob, workspace}` → creates rule + version 1 (Draft). Any role.
- `GET /rules/{id}` — rule + all versions + bindings + which workflows use it.
- `POST /rules/{id}/versions` — Creator: new version `{python_expression, parameter_schema, required_columns, comments, lookup_bindings:[{lookup_alias, ref_dataset_id, lookup_column}]}` (starts Draft; version_no auto-incremented).
- `PUT /rules/{id}/versions/{vid}` — Creator edits while Draft/InReview only; 409 otherwise.
- `POST /rules/{id}/versions/{vid}/status` — `{action, comment}`; transitions per 01 §2 with role checks: submit(Creator: Draft→InReview), review_pass(Reviewer→ApprovedUAT), reject(Reviewer→Rejected), approve(Approver: ApprovedUAT→Approved; atomically retires prior Approved version), retire(Approver/Admin). Appends status_history; audits.
- `POST /rules/{id}/versions/{vid}/dry-run` — Creator: body `{sample_csv (multipart) | dataset_id+batch sample, column, parameters}`; API enqueues a special Worker validation job (never executes rule code in the API process) and returns `{job_id}`; poll `GET /dry-runs/{job_id}` → pass/fail counts + up to 20 failing sample rows. UAT convenience only.

### 3.4 Rule categories `/rule-categories` — GET list, POST/PUT (Admin/Creator).

### 3.5 Workflows `/workflows`
- `GET /workflows` — list + dataset name, status, last run summary.
- `POST /workflows` — create Draft: `{workflow_name, description, dataset_id, trigger_mode, workspace}`. `output_table` name generated: `dq_output.wf_{id}_{slug(workflow_name)}`.
- `GET /workflows/{id}` — full definition: mappings (ordered), groups + members + thresholds.
- `PUT /workflows/{id}` — metadata.
- `PUT /workflows/{id}/mappings` — replace-all mapping set: `[{rule_id, column_name, display_order, parameters}]`. Validation: rule has an Approved (or ApprovedUAT in non-prod) version; column exists in dataset_column; required_columns of the rule version all exist in the dataset; parameters conform to parameter_schema; result_column derived `rule_code + '_' + column_name`; column-count guardrail (01 §8). Diff-apply: new mappings → if workflow Active, `ALTER TABLE ADD COLUMN`; removed → is_active=false (column retained).
- `PUT /workflows/{id}/groups` — replace-all groups: `[{group_name, display_order, pass_threshold, fail_threshold, use_weighted, members:[{mapping_ref, weight}]}]`.
- `POST /workflows/{id}/activate` — validates ≥1 mapping, creates the output table per 01 §8 (idempotent), status→Active. `POST /deactivate` → Inactive.
- `GET /workflows/{id}/output/columns` — ordered output columns (for Views/Explore UIs).

### 3.6 Runs `/runs`
- `POST /workflows/{id}/runs` — manual trigger `{batch_date}` (default: latest Ready batch). 409 `RUN_ALREADY_ACTIVE` if an active run exists (unique index). Inserts Queued; Worker picks it up.
- `GET /runs?workflow_id=&status=&from=&to=` — run history.
- `GET /runs/{id}` — full detail incl. rule_versions_used, error_message.
- `GET /runs/{id}/status` — **lightweight polling endpoint**: `{status, progress_pct, current_step, total_rows, started_at}`. Frontend polls every 2s while Queued/Running. No caching.
- `GET /runs/{id}/summary` — run_rule_summary + run_group_summary rows.
- `GET /runs/{id}/engine-log` — Creator/Admin: engine_log text.
- `POST /runs/{id}/cancel` — Creator/Admin: Queued→Cancelled directly; Running→sets a cancel flag the Worker checks between rules.

### 3.7 Output exploration & views `/views`, `/explore`
- `POST /explore/query` — ad-hoc read: `{base_type, base_id, columns, filters, row_limit, page, page_size}` → rows. Server compiles filters to parameterized SQL against the output/ref table; whitelists column names against actual table columns; ALWAYS filters/orders by batch_date for workflow_output (client may restrict `batch_date` range). CHAR(1) results rendered 'P'→'Pass','F'→'Fail' at serialization.
- `POST /views` — save a view (same shape + view_name). `GET /views`, `GET /views/{id}`, `PUT /views/{id}`, `DELETE /views/{id}` (creator or Admin).
- `GET /views/{id}/run?page=&page_size=` — execute saved view.
- `GET /views/{id}/download` / `POST /explore/download` — stream CSV (chunked cursor, `itersize` ~10K; Content-Disposition filename `{view_name}_{yyyymmdd}.csv`). Audits OUTPUT_DOWNLOADED with row count. Full-table downloads allowed (500K rows streams fine) — but require a batch_date filter or explicit `all_batches=true` flag to prevent accidental 45M-row pulls.

### 3.8 Dashboard/summary feeds `/summaries`
- `GET /summaries/workflows/{id}/trend?days=90` — daily pass_rate & group_status series from summary tables (feeds the charting module).
- `GET /summaries/home` — counts for Home page: active workflows, runs today by status, failing groups today, latest batches.

### 3.9 Admin `/admin`
- `GET/POST/PUT /admin/users` — manage app_user (activate/deactivate).
- `GET/PUT /admin/users/{id}/roles` — set `[{role_name, workspace}]`.
- `GET /admin/audit?user=&event_type=&operation=&object_type=&workspace=&from=&to=` — audit browser (paginated).
- `GET /admin/audit/download?same filters` — streams CSV in the exact DataArc column order: `SpaceName,UserId,UserName,EventType,Operation,EventDate,Message,TargetObjectType,TargetObjectName,SessionId,EventId,TargetObjectId,TargetObjectUuid`. Emits a `Download file / Download Audit CSV` event itself. Admin only.
- `GET /admin/queue` — current Queued/Running runs across workflows (system monitor page).
- `GET /health` — unauthenticated liveness: DB ping.

### 3.10 Export / Import (environment transfer) `/transfer`

Purpose: promote configuration objects (Workflows, Rules, Datasets, Lookup datasets, optionally Views) between environments (DEV → UAT → PROD) as a zip of JSON files — one JSON per object — mirroring the DataArc export/import capability. This is the formal mechanism behind "rule tested in UAT gets updated in PROD".

**Zip layout (format version 1):**
```
dq_export_{env}_{yyyymmdd_hhmm}.zip
  manifest.json                     # format_version, app_version, source_env, exported_by,
                                    # exported_at, workspaces[], index[{type,name,uuid,sha256}]
  workspaces/{workspace}.json       # one per selected workspace (name + description metadata)
  ref_datasets/{name}.json          # registration + columns + rows[] (lookup DATA travels too;
                                    # export warns if a lookup exceeds 100K rows)
  datasets/{dataset_name}.json      # registration + columns; env-specific fields flagged:
                                    # source_path, file_pattern, count_file_pattern
  rules/{rule_code}.json            # rule fields + versions[] (expression, parameter_schema,
                                    # required_columns, status, status_history) + lookup bindings
                                    # referenced by ref_dataset {name, uuid}
  workflows/{workflow_name}.json    # workflow fields + mappings[] as {rule_code, rule_uuid,
                                    # column_name, display_order, parameters} + groups[] with
                                    # members by (rule_code, column_name) + thresholds.
                                    # NEVER: run history, output data, output_table name (regenerated)
  views/{view_name}.json            # optional (checkbox at export)
```
All cross-references inside JSONs use **uuid + natural key**, never local integer ids (01 §11).

**Endpoints (Admin; export also Creator for own workspaces):**
- `POST /transfer/export` — `{workspaces:[...], include:{workflows,rules,datasets,ref_datasets,views}, selected_uuids?:[...]}` → builds zip server-side, streams download. Audits `Export metadata` with the index summary.
- `POST /transfer/import/preview` — multipart zip upload → validates manifest format_version & checksums, resolves every object against the target (by uuid, then natural key within target workspace) → returns per-object plan: `Create | Update (field-level diff) | Identical (skip) | Conflict (name collision with different uuid, or referenced object missing)`. Nothing is written. Preview stored server-side under a `preview_id` (expires 1h).
- `POST /transfer/import/apply` — `{preview_id, options:{rule_status_mode:'as-exported'|'demote-to-ApprovedUAT', dataset_env_fields:'keep-target'|'take-import', workspace_mapping:{src:tgt}}}` → applies in dependency order **ref_datasets → datasets → rules → workflows → views**, each object in its own transaction; imported workflows that are NEW arrive as status Draft (activation — and output-table creation — stays a deliberate local act); UPDATES to existing Active workflows reuse the internal mappings replace-all path so validation + ALTER logic is shared. Emits one `Import metadata` event per applied object + a summary event; returns the full report `{created:[], updated:[], skipped:[], failed:[{object, reason}]}`. Any failed object does not block the rest (report-and-continue), EXCEPT missing dependencies which cascade-skip their dependents.
- `GET /transfer/imports` — history of applies with reports.

**Governance note:** `rule_status_mode` default is `as-exported` (UAT-approved content arrives Approved — matching your current promotion intent); the `demote-to-ApprovedUAT` option exists for stricter targets where the PROD Approver must re-click Approve. Recorded per import in the audit trail either way.

## 4. Validation & error catalogue (agent: implement as constants)

`AUTH_FAILED, TOKEN_EXPIRED, FORBIDDEN, NOT_FOUND, VALIDATION_ERROR, DUPLICATE_NAME, RULE_STATUS_INVALID_TRANSITION, RULE_IN_USE, LOOKUP_IN_USE, DATASET_IN_USE, WORKFLOW_NOT_ACTIVE, RUN_ALREADY_ACTIVE, BATCH_NOT_READY, COLUMN_LIMIT_EXCEEDED, PARAM_SCHEMA_MISMATCH, REQUIRED_COLUMN_MISSING, FILTER_COLUMN_INVALID, IMPORT_FORMAT_UNSUPPORTED, IMPORT_CHECKSUM_MISMATCH, IMPORT_PREVIEW_EXPIRED, IMPORT_DEPENDENCY_MISSING, IMPORT_NAME_CONFLICT`.

## 5. Security requirements (non-negotiable)

JWT secret/keys from env (OpenShift Secret); ldap3 with TLS (`use_ssl` or StartTLS); never store passwords; rate-limit `/auth/login` (e.g., 5/min/user); all SQL parameterized; column names for dynamic SELECTs validated against information_schema whitelist; CORS restricted to the frontend origin; request/response logging excludes payload data values (PII rule 00 §6.8); file uploads size-capped (lookups ≤ 50 MB) and parsed, never executed.

## 6. Database dialect notes (SQLite dev → PostgreSQL prod)

The API uses the same storage abstraction package as the Worker (`worker/storage/`, see 03 §11) for the dialect-sensitive pieces it touches: NameMapper (physical names for `ref_*`/`out_*` tables), PartitionManager.ensure_table/add_result_column (workflow activation & mapping additions). Everything else in the API stays in the portable SQL subset (01 §1): JSON columns are TEXT containing JSON (parse in Python; SQLite JSON1 `json_extract` allowed in read queries only if mirrored by a PG `jsonb_extract_path_text` equivalent inside the storage package — otherwise filter in Python). CSV download streaming: iterate `cursor.fetchmany(10000)` — works identically on both engines. Explore-filter compilation remains parameterized ANSI SQL and is dialect-free. The lookup upload path asks NameMapper for the physical table name and uses plain executemany (small files). No API endpoint changes between dev and prod — only `DATABASE_URL`.
