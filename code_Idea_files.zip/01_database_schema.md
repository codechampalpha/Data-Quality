# 01 — Database Schema (Contract #1) · SQLite-first, PostgreSQL-ready

> **Module role:** the shared contract between API and Worker. Both depend on this file; neither may alter it unilaterally. Any schema change is made HERE first, then propagated.
> **Agent rules:** the DDL below is the **working DDL — SQLite dialect** (development database, single file `data/dq_platform.db`). It is written in a portable subset so the one-time PostgreSQL migration (§10) is mechanical. Generate migrations exactly from this DDL. See the ER diagram in `06_er_diagram.md` / `er_diagram.png`.

## 1. Dual-dialect strategy & portable SQL subset

**Decision:** develop and test entirely on SQLite (PostgreSQL not yet provisioned); migrate to PostgreSQL at PROD deployment. To make that migration a script instead of a rewrite, every module obeys:

1. **Portable subset only** in application SQL: ANSI joins, parameterized statements, `INTEGER PRIMARY KEY`, TEXT/INTEGER/REAL/NUMERIC types, CHECK constraints, partial indexes (both engines support them), `ALTER TABLE ADD COLUMN`. No engine-specific functions in app code (no `now()::date`, no `strftime` in shared code — date math happens in Python).
2. **Four dialect-sensitive concerns** are NEVER written inline; they live behind the storage abstraction layer (03 §11): queue claiming, bulk output writes, batch overwrite/retention, physical name mapping.
3. **Type conventions (SQLite → PostgreSQL):**

| Concern | SQLite (DEV, authoritative now) | PostgreSQL (PROD, later) |
|---|---|---|
| Auto id | `INTEGER PRIMARY KEY` (rowid) | `SERIAL`/`BIGSERIAL` |
| Timestamps | `TEXT` ISO-8601 UTC, `DEFAULT (datetime('now'))` | `TIMESTAMPTZ DEFAULT now()` |
| JSON fields | `TEXT` containing JSON (JSON1 functions available) | `JSONB` |
| Booleans | `INTEGER` 0/1 + CHECK | `BOOLEAN` |
| Schemas | table-name prefixes: (none)=meta, `ref_`, `out_` | schemas `dq_meta`, `dq_ref`, `dq_output` (NameMapper translates) |
| Money/rates | `NUMERIC` | `NUMERIC(p,s)` |
| Concurrency | WAL mode, `busy_timeout=30000`, single-writer discipline | MVCC, `FOR UPDATE SKIP LOCKED` |
| Bulk load | chunked `executemany` (500-row chunks) | `COPY FROM STDIN` |
| Output retention/overwrite | `DELETE ... WHERE batch_date ...` | partition TRUNCATE / DROP |

4. All timestamps are **UTC ISO-8601 strings** end to end; the frontend localizes for display. This removes the biggest SQLite↔PG migration hazard (timezone drift).
5. Bootstrap script MUST set: `PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=30000;` (foreign_keys is per-connection in SQLite — the db module sets it on every connect).

## 2. Rules domain

```sql
CREATE TABLE rule_category (
    rule_type_id     INTEGER PRIMARY KEY,
    rule_type        TEXT NOT NULL UNIQUE,          -- Validity, Completeness, Conformity, Lookup, ...
    rule_type_desc   TEXT
);

CREATE TABLE rule (
    rule_id          INTEGER PRIMARY KEY,
    object_uuid      TEXT NOT NULL UNIQUE,          -- uuid4 at creation; stable identity across environments (§11)
    rule_code        TEXT NOT NULL UNIQUE,          -- 'R101' — used to build output column names
    rule_name        TEXT NOT NULL UNIQUE,          -- 'City Is Valid Check'
    rule_type_id     INTEGER REFERENCES rule_category(rule_type_id),
    business_definition TEXT NOT NULL,              -- plain-English rule from business, with examples
    expected_data_type  TEXT,
    lob              TEXT,
    workspace        TEXT NOT NULL,
    created_by       TEXT NOT NULL,
    created_at       TEXT NOT NULL DEFAULT (datetime('now')),
    is_active        INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1))
);

CREATE TABLE rule_version (
    rule_version_id  INTEGER PRIMARY KEY,
    rule_id          INTEGER NOT NULL REFERENCES rule(rule_id),
    version_no       INTEGER NOT NULL,
    python_expression TEXT NOT NULL,                -- body of evaluate(); contract in 03 §3
    parameter_schema TEXT NOT NULL DEFAULT '{}',    -- JSON: {"min_length":{"type":"int","default":1}}
    required_columns TEXT NOT NULL DEFAULT '[]',    -- JSON array of secondary df columns, e.g. ["mname"]
    status           TEXT NOT NULL DEFAULT 'Draft',
    status_history   TEXT NOT NULL DEFAULT '[]',    -- JSON: [{"status","by","at","comment"}]
    reviewed_by      TEXT,
    approved_by      TEXT,
    approved_at      TEXT,
    retired_at       TEXT,
    comments         TEXT,
    created_by       TEXT NOT NULL,
    created_at       TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (rule_id, version_no),
    CHECK (status IN ('Draft','InReview','ApprovedUAT','Approved','Retired','Rejected'))
);
CREATE UNIQUE INDEX ux_rule_one_approved ON rule_version(rule_id) WHERE status = 'Approved';
CREATE INDEX ix_rule_version_rule ON rule_version(rule_id);

CREATE TABLE rule_lookup_binding (
    binding_id       INTEGER PRIMARY KEY,
    rule_version_id  INTEGER NOT NULL REFERENCES rule_version(rule_version_id) ON DELETE CASCADE,
    lookup_alias     TEXT NOT NULL,                 -- name used inside rule code: lookups['valid_states']
    ref_dataset_id   INTEGER NOT NULL REFERENCES ref_dataset(ref_dataset_id),
    lookup_column    TEXT NOT NULL,
    UNIQUE (rule_version_id, lookup_alias)
);
```

**Status lifecycle (enforced by API, audited via status_history):**
Draft → InReview (Creator submits) → ApprovedUAT (Reviewer passes; UAT-tested) → Approved (Approver signs off; the previous Approved version of the same rule is set to Retired **in the same transaction**) → Retired. InReview → Rejected → back to Draft allowed.

## 3. Reference (lookup) datasets

```sql
CREATE TABLE ref_dataset (
    ref_dataset_id   INTEGER PRIMARY KEY,
    object_uuid      TEXT NOT NULL UNIQUE,
    name             TEXT NOT NULL UNIQUE,
    physical_table   TEXT NOT NULL UNIQUE,          -- SQLite: 'ref_usa_states' ; PG later: 'dq_ref.usa_states'
    description      TEXT,
    columns_json     TEXT NOT NULL,                 -- JSON: [{"name","data_type"}]
    source_file      TEXT,
    row_count        INTEGER NOT NULL DEFAULT 0,
    workspace        TEXT NOT NULL,
    uploaded_by      TEXT NOT NULL,
    loaded_at        TEXT NOT NULL DEFAULT (datetime('now')),
    is_active        INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1))
);
```

Wizard behavior: user provides file (CSV/XLSX), business name, column names + data types → API asks NameMapper for the physical name (`ref_` + sanitized lowercase `[a-z0-9_]`), creates the table, inserts rows. Re-upload with same name = DELETE all + reload + update row_count/loaded_at (overwrite semantics, Admin/Creator only). Physical name collisions rejected.

## 4. Input datasets and batches

```sql
CREATE TABLE dataset (
    dataset_id       INTEGER PRIMARY KEY,
    object_uuid      TEXT NOT NULL UNIQUE,
    dataset_name     TEXT NOT NULL UNIQUE,
    lob              TEXT NOT NULL,
    description      TEXT,
    schedule_type    TEXT NOT NULL DEFAULT 'daily' CHECK (schedule_type IN ('daily','monthly')),
    source_type      TEXT NOT NULL DEFAULT 'ndm'   CHECK (source_type IN ('ndm','impala')),
    source_path      TEXT,
    file_pattern     TEXT,                          -- 'ACCT_MASTER_{YYYYMMDD}.csv'
    count_file_pattern TEXT,                        -- 'ACCT_MASTER_{YYYYMMDD}.cnt'
    delimiter        TEXT NOT NULL DEFAULT ',',
    retention_batches INTEGER NOT NULL DEFAULT 90,
    workspace        TEXT NOT NULL,
    created_by       TEXT NOT NULL,
    created_at       TEXT NOT NULL DEFAULT (datetime('now')),
    is_active        INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1))
);

CREATE TABLE dataset_column (
    dataset_id       INTEGER NOT NULL REFERENCES dataset(dataset_id) ON DELETE CASCADE,
    column_name      TEXT NOT NULL,
    ordinal_position INTEGER NOT NULL,
    data_type        TEXT NOT NULL DEFAULT 'text',
    PRIMARY KEY (dataset_id, column_name)
);

CREATE TABLE dataset_batch (
    batch_id         INTEGER PRIMARY KEY,
    dataset_id       INTEGER NOT NULL REFERENCES dataset(dataset_id),
    batch_date       TEXT NOT NULL,                 -- 'YYYY-MM-DD'
    file_name        TEXT NOT NULL,
    expected_count   INTEGER,
    actual_count     INTEGER,
    load_status      TEXT NOT NULL DEFAULT 'Detected'
        CHECK (load_status IN ('Detected','CountMismatch','Ready','Processed','Failed')),
    detected_at      TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (dataset_id, batch_date)                 -- re-arrival same day = same batch (overwrite)
);
```

Raw input is NEVER persisted in the database (output contains all original columns).

## 5. Workflows

```sql
CREATE TABLE workflow (
    workflow_id      INTEGER PRIMARY KEY,
    object_uuid      TEXT NOT NULL UNIQUE,
    workflow_name    TEXT NOT NULL UNIQUE,
    description      TEXT,
    dataset_id       INTEGER NOT NULL REFERENCES dataset(dataset_id),
    output_table     TEXT NOT NULL UNIQUE,          -- SQLite: 'out_wf_12_acct_master' (NameMapper)
    trigger_mode     TEXT NOT NULL DEFAULT 'auto'  CHECK (trigger_mode IN ('auto','manual')),
    status           TEXT NOT NULL DEFAULT 'Draft' CHECK (status IN ('Draft','Active','Inactive')),
    workspace        TEXT NOT NULL,
    user_class       TEXT,
    created_by       TEXT NOT NULL,
    created_at       TEXT NOT NULL DEFAULT (datetime('now')),
    updated_by       TEXT,
    updated_at       TEXT
);

CREATE TABLE workflow_rule_mapping (
    mapping_id       INTEGER PRIMARY KEY,
    workflow_id      INTEGER NOT NULL REFERENCES workflow(workflow_id) ON DELETE CASCADE,
    rule_id          INTEGER NOT NULL REFERENCES rule(rule_id),   -- version resolved at RUN time = current Approved
    column_name      TEXT NOT NULL,
    display_order    INTEGER NOT NULL,
    parameters       TEXT NOT NULL DEFAULT '{}',    -- JSON per-mapping values matching parameter_schema
    result_column    TEXT NOT NULL,                 -- 'R101_city' (rule_code + '_' + column_name)
    is_active        INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
    added_at         TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (workflow_id, rule_id, column_name)
);

CREATE TABLE workflow_rule_group (
    group_id         INTEGER PRIMARY KEY,
    workflow_id      INTEGER NOT NULL REFERENCES workflow(workflow_id) ON DELETE CASCADE,
    group_name       TEXT NOT NULL,
    display_order    INTEGER NOT NULL,
    pass_threshold   NUMERIC NOT NULL DEFAULT 99.0,     -- rate >= this → Pass
    fail_threshold   NUMERIC NOT NULL DEFAULT 85.0,     -- rate <  this → Fail; between → Warning
    use_weighted     INTEGER NOT NULL DEFAULT 1 CHECK (use_weighted IN (0,1)),
    UNIQUE (workflow_id, group_name),
    CHECK (pass_threshold >= fail_threshold)
);

CREATE TABLE workflow_group_member (
    group_id         INTEGER NOT NULL REFERENCES workflow_rule_group(group_id) ON DELETE CASCADE,
    mapping_id       INTEGER NOT NULL REFERENCES workflow_rule_mapping(mapping_id) ON DELETE CASCADE,
    weight           NUMERIC NOT NULL DEFAULT 1,
    PRIMARY KEY (group_id, mapping_id)
);
```

## 6. Runs (job queue), summaries, dry-run jobs

```sql
CREATE TABLE workflow_run (
    run_id           INTEGER PRIMARY KEY,
    workflow_id      INTEGER NOT NULL REFERENCES workflow(workflow_id),
    batch_id         INTEGER NOT NULL REFERENCES dataset_batch(batch_id),
    batch_date       TEXT NOT NULL,
    trigger_type     TEXT NOT NULL CHECK (trigger_type IN ('auto','manual')),
    triggered_by     TEXT NOT NULL,
    status           TEXT NOT NULL DEFAULT 'Queued'
        CHECK (status IN ('Queued','Running','Completed','Failed','Cancelled')),
    cancel_requested INTEGER NOT NULL DEFAULT 0 CHECK (cancel_requested IN (0,1)),
    queued_at        TEXT NOT NULL DEFAULT (datetime('now')),
    started_at       TEXT,
    completed_at     TEXT,
    total_rows       INTEGER DEFAULT 0,
    progress_pct     NUMERIC DEFAULT 0,
    current_step     TEXT,
    rule_versions_used TEXT,                        -- JSON {"<rule_id>": <rule_version_id>}
    engine_log       TEXT,                          -- generated code + execution log (no data values!)
    error_message    TEXT
);
CREATE UNIQUE INDEX ux_one_active_run_per_wf ON workflow_run(workflow_id)
    WHERE status IN ('Queued','Running');
CREATE INDEX ix_run_status  ON workflow_run(status);
CREATE INDEX ix_run_wf_date ON workflow_run(workflow_id, batch_date);

CREATE TABLE run_rule_summary (
    run_id           INTEGER NOT NULL REFERENCES workflow_run(run_id) ON DELETE CASCADE,
    mapping_id       INTEGER NOT NULL,
    rule_name        TEXT NOT NULL,
    column_name      TEXT NOT NULL,
    passed_rows      INTEGER NOT NULL,
    failed_rows      INTEGER NOT NULL,
    pass_rate        NUMERIC NOT NULL,
    PRIMARY KEY (run_id, mapping_id)
);

CREATE TABLE run_group_summary (
    run_id           INTEGER NOT NULL REFERENCES workflow_run(run_id) ON DELETE CASCADE,
    group_id         INTEGER NOT NULL,
    group_name       TEXT NOT NULL,
    passed_rows      INTEGER NOT NULL,
    failed_rows      INTEGER NOT NULL,
    pass_rate        NUMERIC NOT NULL,
    weighted_pass_rate NUMERIC NOT NULL,
    group_status     TEXT NOT NULL CHECK (group_status IN ('Pass','Warning','Fail')),
    PRIMARY KEY (run_id, group_id)
);

CREATE TABLE dry_run_job (
    job_id           INTEGER PRIMARY KEY,
    rule_version_id  INTEGER NOT NULL REFERENCES rule_version(rule_version_id),
    column_name      TEXT NOT NULL,
    parameters       TEXT NOT NULL DEFAULT '{}',    -- JSON
    sample_path      TEXT NOT NULL,                 -- server-side stored sample CSV (<=100K rows)
    status           TEXT NOT NULL DEFAULT 'Queued'
        CHECK (status IN ('Queued','Running','Completed','Failed')),
    result           TEXT,                          -- JSON {passed, failed, sample_failing:[...]}
    created_by       TEXT NOT NULL,
    created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);
```

`workflow_run` doubles as the job queue: the API INSERTs Queued rows; the Worker claims them via the QueueClaimer (03 §11) — `BEGIN IMMEDIATE` + guarded UPDATE on SQLite, `FOR UPDATE SKIP LOCKED` on PostgreSQL. The partial unique index makes duplicate active runs of one workflow impossible at the database level **in both engines**.

## 7. Users, roles, views, audit

```sql
CREATE TABLE app_user (
    user_id      INTEGER PRIMARY KEY,
    username     TEXT NOT NULL UNIQUE,          -- corporate ID (AD sAMAccountName / SSO subject)
    display_name TEXT,
    email        TEXT,
    is_active    INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE role (
    role_id      INTEGER PRIMARY KEY,
    role_name    TEXT NOT NULL UNIQUE           -- Admin | Creator | Approver | Reviewer | Explorer
);

CREATE TABLE user_role (
    user_id      INTEGER NOT NULL REFERENCES app_user(user_id),
    role_id      INTEGER NOT NULL REFERENCES role(role_id),
    workspace    TEXT NOT NULL,
    PRIMARY KEY (user_id, role_id, workspace)
);

CREATE TABLE saved_view (
    view_id      INTEGER PRIMARY KEY,
    object_uuid  TEXT NOT NULL UNIQUE,
    view_name    TEXT NOT NULL,
    base_type    TEXT NOT NULL CHECK (base_type IN ('workflow_output','ref_dataset')),
    base_id      INTEGER NOT NULL,
    columns_json TEXT NOT NULL,                 -- JSON ordered selected columns
    filters_json TEXT NOT NULL DEFAULT '[]',    -- JSON [{"column","operator","value"}]
    row_limit    INTEGER,
    workspace    TEXT NOT NULL,
    created_by   TEXT NOT NULL,
    created_at   TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (workspace, view_name)
);

-- Event model aligned to the DataArc/Aperture audit export so downloaded CSVs are drop-in
-- compatible for auditors (columns: SpaceName, UserId, UserName, EventType, Operation, EventDate,
-- Message, TargetObjectType, TargetObjectName, SessionId, EventId, TargetObjectId, TargetObjectUuid).
CREATE TABLE audit_log (
    event_id           INTEGER PRIMARY KEY,            -- exported as EventId
    workspace          TEXT,                           -- SpaceName ('' for system-level events)
    user_id            TEXT,                           -- UserId (corporate id; 'System' for automation)
    user_name          TEXT,                           -- UserName (display name)
    event_type         TEXT NOT NULL,                  -- category, see catalogue below
    operation          TEXT NOT NULL,                  -- specific action, e.g. 'Create Rule'
    event_date         TEXT NOT NULL DEFAULT (datetime('now')),
    message            TEXT NOT NULL,                  -- human-readable, e.g. "Created Rule 'R151'"
    target_object_type TEXT,                           -- Workflow|Rule|RuleVersion|Dataset|RefDataset|View|User|Run|System
    target_object_name TEXT,
    target_object_id   TEXT,                           -- local integer id as text
    target_object_uuid TEXT,                           -- stable cross-environment uuid (see §11)
    session_id         TEXT,                           -- JWT jti claim
    details            TEXT                            -- JSON extras (row counts, before/after, etc.)
);
CREATE INDEX ix_audit_user_time ON audit_log(user_id, event_date);
CREATE INDEX ix_audit_type_time ON audit_log(event_type, event_date);
```

Seed data: the five `role` rows; one Admin `app_user`.

## 8. Output tables — dynamic DDL pattern (dialect-managed)

Created by the PartitionManager on workflow activation — NOT part of static migrations.

**SQLite (DEV) — single plain table:**
```sql
CREATE TABLE out_wf_{workflow_id}_{slug} (
    rec_id       INTEGER NOT NULL,
    batch_date   TEXT    NOT NULL,
    run_id       INTEGER NOT NULL,
    {original columns ... TEXT},
    "{result_column}" TEXT CHECK ("{result_column}" IN ('P','F'))   -- one per mapping
);
CREATE INDEX ix_out_wf_{id}_batch ON out_wf_{workflow_id}_{slug}(batch_date);
```
Overwrite = `DELETE FROM ... WHERE batch_date = ?`; retention = `DELETE ... WHERE batch_date < ?` (+ periodic `PRAGMA incremental_vacuum` / VACUUM job — dev volumes make this trivial).

**PostgreSQL (PROD) — same logical shape, physically partitioned:**
```sql
CREATE TABLE dq_output.wf_{workflow_id}_{slug} ( ...same columns..., result cols CHAR(1) )
PARTITION BY RANGE (batch_date);
-- one partition per batch (daily ..._pYYYYMMDD / monthly ..._pYYYYMM), created just-in-time
```
Overwrite = TRUNCATE partition; retention = DROP partitions beyond newest `retention_batches`.

Shared rules regardless of engine: column order = `rec_id, batch_date, run_id`, dataset columns by ordinal_position, result columns by display_order; adding a mapping later = `ALTER TABLE ... ADD COLUMN` (supported by both; history reads NULL); deactivated mappings keep their column; guardrail: SQLite max 2000 columns (default build) / PG ~1600 — workflow editor validates `3 + originals + results ≤ 1500`.

## 9. Migration plan from demo SQLite

One-time scripts (`migrations/bootstrap/`):
1. `001_schema.sql` — everything in §2–§7 above + seed roles/admin (idempotent: `CREATE TABLE IF NOT EXISTS` acceptable here).
2. `migrate_lookups.py` — copy each demo lookup (usa_states, statecode_names, invalid_words_name_address, metro_2_domain_alphabet, phocheck_values, special_characters_all, valid_account_type_codes, ac/account status code defs) → `ref_*` tables + register in ref_dataset.
3. `load_rules.py` — load the 150 converted rules into rule + rule_version (status ApprovedUAT; Approver bulk-promotes after UAT re-verification), incl. lookup bindings + required_columns.
NOT carried forward: execution_results (per-record-per-rule — forbidden at scale), wf1_validation_results_by_rule (→ run_group_summary), workflow_list/column_rule_mappings (→ §5), dashboard_list.

## 10. Migration plan SQLite → PostgreSQL (PROD cutover, later)

A scripted one-time exercise, `migrations/to_postgres/`:
1. `pg_schema.sql` — this document's DDL translated per the §1 type table, plus schemas dq_meta/dq_ref/dq_output and the partitioned-output template. (Agent generates it FROM this file when the task arrives — single source of truth.)
2. `pump.py` — table-by-table copy in FK order (SQLite reader → psycopg2 COPY writer); ref_/out_ tables mapped by NameMapper (`ref_x` → `dq_ref.x`, `out_wf_…` → `dq_output.wf_…`); output rows land in auto-created partitions; sequences (`setval`) aligned to max(id).
3. Verify: row counts per table; checksum spot-samples; re-run one workflow on PG and compare to its SQLite output for the same batch.
4. Flip `DATABASE_URL`; storage abstraction switches QueueClaimer/BulkWriter/PartitionManager to the PG implementations automatically (03 §11). No application-code changes.
Practice run: the whole §10 can be rehearsed on the office Mac's OpenShift Local with a containerized PostgreSQL before real PROD exists — recommended as its own build-plan task.

## 11. Cross-environment object identity & audit event catalogue

**Object UUIDs.** Every transferable object (rule, workflow, dataset, ref_dataset, saved_view) carries `object_uuid` (uuid4, generated at creation, immutable, UNIQUE). Integer ids remain the local PK/FK mechanics but NEVER travel between environments; the export/import feature (02 §3.10) matches objects by uuid first, natural key (rule_code / workflow_name / dataset_name / name) second. rule_version identity across environments = (rule object_uuid, version_no).

**Audit event catalogue** (event_type → operations). API implements as constants; every mutating endpoint emits exactly one event:

| event_type | operations (target_object_type) |
|---|---|
| Authenticate | Authentication: 'Ldap' (User) |
| Create object | Create Rule / Create Rule Version / Create Dataset / Create RefDataset / Create Workflow / Create View |
| Update object | Update Rule / Update Rule Version / Update Dataset / Update RefDataset / Update Workflow / Update View / Update User Roles |
| Delete object | Delete View / Deactivate RefDataset / Deactivate Dataset / Deactivate Workflow |
| Publish object | Approve Rule Version (RuleVersion) / Activate Workflow (Workflow) |
| Execute Workflow | Trigger Run / Cancel Run (Run) — Worker also emits Run Completed / Run Failed |
| New data uploaded | Lookup data reloaded (RefDataset) / Batch detected (Dataset — Worker) |
| Download file | Download View CSV / Download Output CSV / Download Audit CSV / Download Export Zip |
| Export metadata | Export workspace objects (System) |
| Import metadata | Import preview / Import apply — one event per applied object + one summary (System) |

The audit CSV download (02 §3.9) emits exactly the DataArc column set in the table comment above, so existing audit tooling consumes it unchanged.
