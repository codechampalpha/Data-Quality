# AGENT_PROMPTS.md — Copy-Paste Prompts for VS Code Sessions

Setup once: put CLAUDE.md, PROGRESS.md, AGENT_PROMPTS.md at the repo root and the eight spec files in `specs/`. Claude Code auto-reads CLAUDE.md; if you use a different agent (Cline, Copilot agent), start every prompt with: `First read CLAUDE.md and follow it strictly.` Then paste one prompt below per session. Keep sessions to ONE task.

---

## P1 — KICKOFF (run once, first session)
```
Read CLAUDE.md, PROGRESS.md, specs/00_system_overview.md and specs/05_build_plan.md.
This repo contains our EXISTING demo application (React frontend, Flask backend, SQLite).
Do NOT write feature code this session. Instead:
1. Inventory the existing codebase: list frontend pages/components, Flask routes/modules,
   and DB tables actually present.
2. Map each item to the target design: keep / adapt / replace / delete, citing the spec
   section it will serve. Write this into PROGRESS.md ("Frontend reuse inventory" plus a
   new "Backend reuse inventory" section).
3. Propose the file moves needed to reach the CLAUDE.md repository layout (do not move yet).
4. Update the task board notes where existing code changes a task's effort.
End by summarizing in 10 lines what T0 should do given this inventory.
```

## P2 — EXECUTE NEXT TASK (the everyday prompt)
```
Read CLAUDE.md and PROGRESS.md. Execute task <T__> from specs/05_build_plan.md.
Load ONLY the spec files that task's Load-list names. State the acceptance criteria first,
implement, run the acceptance checks, show me the evidence (test output / command results),
then update PROGRESS.md (status, files touched, decisions). One task only — do not start
the next one.
```

## P3 — RESUME AN INTERRUPTED TASK
```
Read CLAUDE.md and PROGRESS.md. Task <T__> is ◐ in progress — resume EXACTLY from the
"Resume TODO" list in PROGRESS.md without re-reading unrelated code. Finish the remaining
items, run the acceptance checks, show evidence, update PROGRESS.md.
```

## P4 — CHANGE REQUEST (Kiro-style; use for every new/changed requirement)
```
Read CLAUDE.md and PROGRESS.md. This is a CHANGE REQUEST — follow the spec-change workflow
in CLAUDE.md strictly (requirements → spec design edit → tasks → only then code, and STOP
for approval at each confirmation point).

Change: <describe the change in plain language>

Step 1 now: restate it as 3–6 acceptance criteria and tell me which spec file/section(s)
would change and whether any change touches contract 01 or 02. Then WAIT for my confirmation.
```

## P5 — APPLY AN APPROVED SPEC EDIT
```
Read CLAUDE.md. I have approved the spec change for <topic> as discussed. Apply the agreed
edit to <specs/0X_file.md §Y> exactly, append the new task(s) to specs/05_build_plan.md with
the next free ID (Load-list, prompt, acceptance criteria), add them to the PROGRESS.md board,
and log the change in "Decisions log" (or "Contract Change Requests" → applied, if 01/02).
Do NOT implement yet.
```

## P6 — REVIEW / VERIFY A MODULE
```
Read CLAUDE.md. Audit <api|worker|frontend> against its spec (<specs/0X_...>) and the hard
rules in CLAUDE.md. Do not change code. Report: (a) spec sections fully met, (b) gaps or
drift with file:line references, (c) any hard-rule violations (dialect leaks outside
worker/storage, missing audit events, unparameterized SQL, PII in logs), (d) suggested
fix tasks sized ≤1 session each. Append findings to PROGRESS.md.
```

## P7 — END-OF-SESSION SAFETY NET (paste when you see tokens running out)
```
Stop coding now. Update PROGRESS.md: task status, files touched this session, and a
"Resume TODO" list precise enough that a fresh session needs no code re-reading. Commit
with message "T<ID> (partial): <summary>".
```

---

## Weekly rhythm that works with a small token budget
Mon–Thu: one P2 session per day (or P4→P5→P2 when a change lands). Fri: one P6 review on
the module you touched most. Any day tokens run low: P7, walk away, P3 tomorrow. Bring
contract-level questions (01/02 changes, new dependencies, design doubts) back to the
design assistant with just the affected spec file — not to the coding agent.
