# 05 — Build Plan: Step-by-Step Tasks for the VS Code Agent

> **Module role:** execution roadmap. Ordered tasks, each with: files to load, a ready-to-paste prompt, and acceptance criteria. Work top to bottom; do not start a task until the previous task's acceptance criteria pass.

## Token Protocol (limited Sonnet budget — follow strictly)

1. Every session: load `00_system_overview.md` + ONLY the module spec(s) named by the task. Never load all six.
2. One task per session where possible. Start the session with the task prompt verbatim; end by running the acceptance checks.
3. If the agent proposes changing 01 or 02 (the contracts), STOP the session, note the proposed change, and resolve it as a deliberate contract decision (discuss module impact first). This is the isolation guarantee.
4. Keep a running `PROGRESS.md` in the repo root: task ID, date, status, deviations. Load it in every session (it is small) so the agent knows the state without re-reading code.
5. When a task partially completes and tokens run low: have the agent write remaining steps into PROGRESS.md as a TODO before ending.

## Repository layout (create in Task 0)

```
dq-platform/
  PROGRESS.md
  specs/               # these six files
  api/                 # Flask service (02)
  worker/              # engine service (03)
  frontend/            # React app (04)
  migrations/          # bootstrap SQL + one-time scripts (01 §9)
  deploy/              # Dockerfiles, OpenShift manifests
  samples/             # fixture CSVs, sample rules, count files
```

---

## PHASE 1 — Foundation & Engine Core (all development on SQLite — 01 §1)

**T0 — Scaffold.** Load: 00. Prompt: "Create the repository layout from 05 §Repository layout, with a PROGRESS.md, .gitignore for Python/Node, and empty package skeletons (api, worker as Python packages with settings modules reading env; frontend as the existing React app moved in)." Accept: tree matches; `python -c "import api, worker"` passes.

**T1 — Database bootstrap (SQLite).** Load: 00, 01. Prompt: "Implement migrations/bootstrap/001_schema.sql containing every CREATE in 01 §2–§7 exactly (SQLite dialect), plus seed rows for the five roles and one Admin user, and a bootstrap script that creates data/dq_platform.db, applies the DDL, and sets PRAGMA journal_mode=WAL." Accept: script applies cleanly twice; all tables present via sqlite_master; inserting two Approved versions for one rule fails on ux_rule_one_approved; foreign_keys enforced on a violating insert.

**T1b — Storage abstraction layer.** Load: 00, 01 §1+§8, 03 §11. Prompt: "Implement worker/storage/: NameMapper, QueueClaimer, BulkWriter, PartitionManager with SQLite implementations complete and PostgreSQL implementations stubbed behind the same interfaces (raise NotImplementedError with a pointer to task T26b). Dialect chosen from DATABASE_URL. pytest: claim race (two threads, one winner), bulk write round-trip on a 50-column frame, prepare_batch/retire delete semantics." Accept: tests green; no other module contains dialect-branching SQL (grep check for 'SKIP LOCKED' outside storage/).

**T2 — Sample fixtures.** Load: 00, 03 §3. Prompt: "Create samples/: input_1k.csv (1,000 rows with columns fname, mname, sname, city, state plus 10 filler columns; include edge cases — empty names, hyphen-leading names, invalid words like TRUST/LLC, city 'TWENTYNINE PALMS', bad state codes), input_1k.cnt containing 1000, lookups usa_states.csv and invalid_words.csv, and rules_seed.py that inserts 3 rules (City Is Valid, First Name Is Valid, Surname Is Valid) with rule_version status Approved, python_expression per the contract in 03 §3, lookup bindings to invalid_words, and required_columns ['mname'] for the First Name rule." Accept: seed script runs; rule_version rows exist with valid JSON fields. (Use fabricated data only — no real customer records in samples.)

**T3 — Rule runtime.** Load: 00, 03 (§3, §10.1). Prompt: "Implement worker/rule_runtime.py: SAFE_BUILTINS, ALLOWED_GLOBALS, build_rule_fn, result normalization (fillna(False).astype(bool)), and the internal RuleResult wrapper. pytest per 03 §10.1." Accept: all tests green, including namespace-restriction tests.

**T4 — Engine core (the milestone task).** Load: 00, 01 §6+§8, 03 §4–§5. Prompt: "Implement worker/engine.py run lifecycle phases 1–9 per 03 §4, worker/output_writer.py per 03 §5, worker/summaries.py, worker/retention.py, worker/db.py. Provide `python -m worker.run_once --workflow-id X --batch-date D` for manual execution. Follow the failure policy exactly: any rule error → run Failed → nothing written / partition truncated." Accept: with T1–T3 in place and a workflow wired manually via SQL (samples README shows the INSERTs), run_once completes on SQLite: output table exists with correct column order, 1,000 rows, P/F values matching a golden CSV; summaries populated; re-running same day yields identical rec_ids and no duplicates (DELETE-overwrite verified); injecting a broken rule leaves output empty and run Failed.

**T5 — Retention & overwrite proof.** Load: 00, 01 §8, 03 §4 phase 8 + §11.3. Prompt: "Add tests: write 5 daily batches for the T4 workflow with retention_batches=3; run retire; assert oldest 2 batches' rows gone and newest 3 intact; same-day prepare_batch removes exactly that day. Add monthly-mode test." Accept: tests green on SQLite (suite parameterized to also run on PG when available).

## PHASE 2 — Automation & Operations

**T6 — Poller.** Load: 00, 03 §2. Accept per 03 §10.6 (count mismatch, stable-size guard, duplicate suppression).
**T7 — Dispatcher & parallelism.** Load: 00, 03 §1+§4 claim SQL. Accept: two workflows queued → run concurrently (MAX_PARALLEL_RUNS=2); same workflow queued twice → second insert rejected; SIGTERM mid-run → graceful finish; kill -9 then restart → stuck run marked Failed and partition truncated.
**T8 — Cancel + timeout + engine_log.** Load: 00, 03 §4+§8. Accept: cancel flag honored between rules; RUN_TIMEOUT_MIN enforced; engine_log contains generated sources and no data values (test asserts a known cell value never appears in log).

## PHASE 3 — API

**T9 — Auth & RBAC skeleton.** Load: 00, 02 §1–§2. Accept: login against a stub/LDAP test double issues JWT; @require_role enforced; /health open; audit row on login.
**T10 — Datasets + lookups endpoints.** Load: 00, 01 §3–§4, 02 §3.1–§3.2. Accept: lookup upload creates dq_ref table + registration; re-upload truncates/reloads; DELETE returns 409 when bound.
**T11 — Rules lifecycle endpoints.** Load: 00, 01 §2, 02 §3.3–§3.4. Accept: full Draft→Approved path with role checks; approving version 2 retires version 1 atomically; invalid transition → RULE_STATUS_INVALID_TRANSITION.
**T12 — Workflows endpoints.** Load: 00, 01 §5+§8, 02 §3.5. Accept: mappings replace-all with validation catalogue errors; activate creates output table idempotently; adding mapping to Active workflow ALTERs table.
**T13 — Runs endpoints.** Load: 00, 01 §6, 02 §3.6. Accept: manual trigger 409s on active run; status polling endpoint <10ms query; cancel semantics per spec.
**T14 — Explore/views/downloads + summaries + admin.** Load: 00, 02 §3.7–§3.9. Accept: filter compilation parameterized (SQL-injection test with `'; DROP` as a filter value returns rows/none, never errors the server); CSV streaming of 500K rows under constant memory; downloads audited.
**T14b — Audit event model + CSV download.** Load: 00, 01 §7+§11, 02 §3.9. Prompt: "Implement the audit service: emit_event(event_type, operation, message, target, session) helper used by every mutating route; GET /admin/audit with filters; GET /admin/audit/download streaming the exact DataArc column order." Accept: download of seeded events opens in Excel with the 13 expected columns; every mutating endpoint test asserts exactly one event.

**T15 — Dry-run job path.** Load: 00, 02 §3.3 dry-run, 03 §6. Contract note: adds dry_run_job table to 01 — record the contract change in PROGRESS.md and update 01 §6 accordingly before implementing.

## PHASE 4 — Frontend (each task loads 00 + 04 section + the 02 sections it calls)

**T16 — Reuse audit + shell.** FIRST: inventory the existing React app (components, wizards, grids, auth) and write the keep/adapt/build-new map into PROGRESS.md; THEN wire shell, login, auth context, api.js client from existing pieces. (04 header: REUSE FIRST.) **T17** Home + Dashboard. **T18** Datasets pages + both wizards. **T19** Rules pages (list, propose, detail hub with lifecycle actions, code editor, dry-run tab). **T20** Workflow designer (dual listbox, ordering, params popovers, groups/thresholds pane) — the largest UI task; split sub-sessions: left pane / right pane / save-activate. **T21** Run history + run detail with live progress. **T22** Views builder + list + downloads. **T23** Issue List, User Settings, System pages.
Accept (each): screens function against the running API; role visibility matches 02 §2; error catalogue codes surfaced as friendly toasts.

## PHASE 5 — Migration, Validation, Deployment

**T23b — Export/Import (environment transfer).** Load: 00, 01 §11, 02 §3.10, 04 §13.8. Prompt: "Implement /transfer/export (zip builder: manifest + one JSON per object, uuid+natural-key references, sha256 index), /transfer/import/preview (resolve, diff, plan), /transfer/import/apply (dependency-ordered upsert with options), plus the System Export/Import wizard screens." Accept: round-trip test — export workspace A from DB1, import into empty DB2, re-export from DB2: object JSONs semantically identical (ignoring local ids/timestamps); conflict case (same name, different uuid) surfaces as Conflict not overwrite; new workflow arrives Draft; report + audit events complete.

**T24 — Rule migration loader.** Load: 00, 01 §9. Convert the exported 150 rules workbook into rule/rule_version/bindings inserts (status ApprovedUAT).
**T25 — Comparison utility.** Load: 00, 03 §7. Accept: given our output + a synthetic "Experian" file with 3 planted mismatches, report finds exactly those 3.
**T26 — Deployment (dev-parity first).** Load: 00 §2+§7. Dockerfiles (api, worker, frontend/nginx), OpenShift manifests (Deployments, Services, Route, Secrets refs, shared PVC holding the SQLite file + NDM volume read-only, worker terminationGracePeriod 900). Verified on the office Mac's OpenShift Local.

**T26b — PostgreSQL migration (when PROD DB exists).** Load: 00, 01 §10, 03 §11. Prompt: "Generate migrations/to_postgres/pg_schema.sql from 01 per the §1 type table; implement pump.py (FK-ordered copy, NameMapper translation, sequence alignment); complete the PG implementations of QueueClaimer/BulkWriter/PartitionManager; run the full worker test suite against PG." Accept: row counts match; one workflow re-run on PG equals its SQLite output for the same batch; rehearsal executed on OpenShift Local with containerized PostgreSQL before real PROD.
**T27 — Parallel-run window.** Operational, not code: daily compare per 03 §7 for the agreed window; zero unexplained mismatches → business sign-off → cutover.

---

## Definition of Done (system level)
One real dataset flowing daily end-to-end: file lands → auto-run → wide output partition + summaries → visible in Views/Dashboard → 90-day retention proven → results matching Experian Data Studio over the parallel window → RBAC and audit verified.
