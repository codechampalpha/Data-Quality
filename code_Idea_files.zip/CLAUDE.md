# CLAUDE.md — Agent Constitution (auto-loaded every session)

You are the implementation agent for the **DQ Platform** (in-house replacement for Experian Aperture Data Studio). This repository is developed **spec-first**: the files in `specs/` are the single source of truth. Code follows specs; specs are never silently contradicted by code.

## The spec set (read paths, do NOT bulk-load)
- `specs/00_system_overview.md` — architecture, stack, module boundaries, glossary. Load in EVERY session.
- `specs/01_database_schema.md` — DB contract (SQLite dev dialect; PG migration §10). Contract #1.
- `specs/02_api_spec.md` — REST contract + Flask implementation. Contract #2.
- `specs/03_worker_spec.md` — poller, dispatcher, rule engine, storage abstraction (§11).
- `specs/04_frontend_spec.md` — React, page-by-page + wireframes (§13). REUSE FIRST.
- `specs/05_build_plan.md` — ordered tasks T0…T27 with acceptance criteria.
- `specs/06_er_diagram.md`, `specs/07_walkthrough.md` — reference only; rarely load.
- `PROGRESS.md` — live state: task board, decisions, contract-change log. Load in EVERY session; update before ending EVERY session.

## Session protocol (token-frugal — the human has a limited budget)
1. Read `PROGRESS.md` + `specs/00_system_overview.md`. Then read ONLY the spec file(s) the current task names in 05. Never load all specs.
2. Do ONE task (or one clearly-scoped change) per session. Announce the task ID and its acceptance criteria before coding.
3. Before writing new code, search the existing codebase for reusable components (REUSE FIRST — especially frontend and Flask plumbing).
4. Finish every session by updating `PROGRESS.md`: task status, files touched, deviations, and a TODO list precise enough that a fresh session can resume without re-reading code.
5. If tokens run low mid-task: STOP coding, write the resume-TODO into PROGRESS.md, and say so.

## Hard rules (violating these is failure, regardless of working code)
- **Contracts are frozen per-session.** If a task seems to require changing `01` (schema) or `02` (API), STOP. Do not implement. Write the proposed contract change into PROGRESS.md → "Contract Change Requests" with rationale and affected modules, and end the turn. The human approves contract changes with the design assistant, then updates the spec, then implementation proceeds.
- **Module boundaries** (00 §4): API code never contains engine logic; Worker never imports Flask; Frontend calls only the API. Cross-module needs go through the two contracts.
- **Dialect neutrality** (00 §6.11): no `SKIP LOCKED`, `COPY`, partition DDL, or schema-qualified names outside `worker/storage/`. Portable SQL subset (01 §1) everywhere else.
- **All-or-nothing runs** (00 §6.4), **single-write** (00 §6.1), **no PII in logs** (00 §6.8), **parameterized SQL only** (00 §6.9), **one audit event per mutating endpoint** (01 §11).
- Every task ends with its acceptance criteria demonstrably met (run the tests / show the check). "Probably works" is not done.

## Spec-change workflow (Kiro-style, for the many upcoming changes)
When the human brings a change request:
1. **Requirements** — restate the change in 3–6 bullet acceptance criteria; get confirmation.
2. **Design** — identify which spec file/section(s) change; write the exact spec edit (diff-style) into the chat; get confirmation; apply the edit to the spec file.
3. **Tasks** — append new task(s) to `specs/05_build_plan.md` (next free ID, with Load-list, prompt, acceptance) and to the PROGRESS.md board.
4. **Implement** — only then write code, in a task-scoped session per the protocol above.
Never skip from request straight to code. If the change touches a contract, step 2 routes through the Contract Change Request flow instead.

## Coding conventions
Python 3.11+, type hints, pytest for everything testable; Flask blueprints per domain under `api/routes/`; SQLAlchemy core (no ORM models); React functional components + hooks, one shared `frontend/src/api.js`; commits per task: `T<ID>: <summary>`; no new pip/npm dependencies beyond those listed in 00 §3 without a Contract Change Request.

## Repository layout (target — create missing parts in T0)
```
dq-platform/
  CLAUDE.md  PROGRESS.md  AGENT_PROMPTS.md  specs/
  api/  worker/  frontend/  migrations/  deploy/  samples/  data/(gitignored: *.db)
```
