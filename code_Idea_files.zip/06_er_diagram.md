# 06 — Entity-Relationship Diagram

Rendered images: `er_diagram.png` (150 dpi) and `er_diagram.svg` (crisp at any zoom) — generated from `er.dot` (Graphviz source, included for regeneration after schema changes). Below, the same model as Mermaid for inline preview in VS Code (Markdown Preview Mermaid Support extension) — update BOTH when 01 changes.

## Reading guide
Object UUIDs on rule/workflow/dataset/ref_dataset/saved_view are the stable cross-environment identity used by export/import (01 §11). Five domains: **Rules** (blue in PNG) — definition/version/lookup bindings; **Datasets & Lookups** (green) — registered feeds, columns, batches, reference tables; **Workflows** (orange) — mappings and weighted groups; **Execution** (purple) — run queue, summaries, dry-runs; **Security** (grey) — users/roles/views/audit. The yellow `out_wf_*` box is the dynamic per-workflow output table (not in static DDL). The two DB-enforced singletons: one Approved rule_version per rule; one active run per workflow.

```mermaid
erDiagram
    rule_category ||--o{ rule : categorizes
    rule ||--|{ rule_version : "versions (1 Approved max)"
    rule_version ||--o{ rule_lookup_binding : uses
    ref_dataset ||--o{ rule_lookup_binding : feeds
    dataset ||--|{ dataset_column : has
    dataset ||--o{ dataset_batch : receives
    dataset ||--o{ workflow : validated_by
    workflow ||--|{ workflow_rule_mapping : maps
    rule ||--o{ workflow_rule_mapping : applied_as
    workflow ||--o{ workflow_rule_group : groups
    workflow_rule_group ||--o{ workflow_group_member : contains
    workflow_rule_mapping ||--o{ workflow_group_member : member_of
    workflow ||--o{ workflow_run : executes
    dataset_batch ||--o{ workflow_run : processed_in
    workflow_run ||--o{ run_rule_summary : summarizes
    workflow_run ||--o{ run_group_summary : scores
    rule_version ||--o{ dry_run_job : tested_by
    app_user ||--o{ user_role : holds
    role ||--o{ user_role : grants

    rule { int rule_id PK
           text object_uuid UK
           text rule_code UK
           text rule_name UK
           text business_definition }
    rule_version { int rule_version_id PK
                   int rule_id FK
                   text python_expression
                   text status
                   text parameter_schema
                   text required_columns }
    rule_lookup_binding { int binding_id PK
                          text lookup_alias
                          text lookup_column }
    ref_dataset { int ref_dataset_id PK
                  text object_uuid UK
                  text name UK
                  text physical_table UK }
    dataset { int dataset_id PK
              text object_uuid UK
              text dataset_name UK
              text schedule_type
              int retention_batches }
    dataset_column { text column_name PK
                     int ordinal_position }
    dataset_batch { int batch_id PK
                    text batch_date
                    int expected_count
                    text load_status }
    workflow { int workflow_id PK
               text object_uuid UK
               text workflow_name UK
               text output_table UK
               text trigger_mode
               text status }
    workflow_rule_mapping { int mapping_id PK
                            text column_name
                            int display_order
                            text result_column }
    workflow_rule_group { int group_id PK
                          text group_name
                          numeric pass_threshold
                          numeric fail_threshold }
    workflow_group_member { numeric weight }
    workflow_run { int run_id PK
                   text status
                   numeric progress_pct
                   text rule_versions_used
                   text engine_log }
    run_rule_summary { int passed_rows
                       int failed_rows
                       numeric pass_rate }
    run_group_summary { numeric weighted_pass_rate
                        text group_status }
    dry_run_job { int job_id PK
                  text sample_path
                  text result }
    app_user { int user_id PK
               text username UK }
    role { text role_name UK }
    user_role { text workspace PK }
    saved_view { int view_id PK
                 text object_uuid UK
                 text base_type
                 text columns_json
                 text filters_json }
    audit_log { int event_id PK
                text event_type
                text operation
                text message
                text target_object_uuid
                text event_date }
```

Not shown as entities (dynamic): `ref_*` physical lookup tables (one per ref_dataset registration) and `out_wf_{id}_{slug}` output tables (one per workflow; written by workflow_run; SQLite plain table / PostgreSQL partitioned).
